GrifoMania WordPress Plugin — Prototype 0.1.0

INSTALLATION
1. In WordPress, go to Plugins > Add New Plugin > Upload Plugin.
2. Upload grifomania-0.1.0.zip and activate it.
3. Create a page named "GrifoMania".
4. Add this shortcode to the page: [grifomania]
5. Publish and open the page on a phone or desktop.

WHAT THIS PROTOTYPE INCLUDES
- Responsive bilingual (Greek/English) game interface.
- First playable level with three short puzzle challenges.
- Points, hints, feedback, progress bar and completion screen.
- Guest progress saved in the browser's localStorage.

IMPORTANT LIMITATIONS
- This is an early playable prototype, not the final app.
- Progress is currently saved only in the browser/device where the player plays.
- Google and Apple sign-in, server-side player profiles, cross-device sync, leaderboards,
  ad integration and the remaining levels are not implemented yet.
- Before public release, the puzzles, accessibility, security, privacy and store requirements
  need further review and testing.
