(() => {
  "use strict";
  const root = document.getElementById("grifomania-app");
  if (!root || !window.GrifoManiaConfig) return;

  const cfg = window.GrifoManiaConfig;
  const key = cfg.storageKey;
  const $ = (id) => document.getElementById(id);
  const defaults = { language: "el", step: 0, points: 0, solved: [false,false,false], hints: [false,false,false], started: false, completed: false };
  let state = loadState();
  let selectedShape = -1;
  let answered = false;

  const puzzles = [
    { title: {el:"Ο κώδικας των αριθμών",en:"The Number Code"}, text:{el:"Στην πέτρινη πλάκα είναι χαραγμένη η ακολουθία: 2, 4, 8, 16, __. Ποιος αριθμός συμπληρώνει τον κώδικα;",en:"The stone tablet shows this sequence: 2, 4, 8, 16, __. Which number completes the code?"}, art:"Ⅱ　Ⅳ　Ⅷ　ⅩⅥ　?", hint:{el:"Κοίτα πόσο αυξάνεται κάθε φορά ο αριθμός.",en:"Look at how the number changes each time."}, type:"text", answers:["32"], points:100 },
    { title:{el:"Το σημάδι που περισσεύει",en:"The Odd Mark"}, text:{el:"Τρία από τα παρακάτω είναι πολύγωνα. Ποιο σύμβολο δεν είναι πολύγωνο;",en:"Three of the following are polygons. Which symbol is not a polygon?"}, art:"○　△　□　★", hint:{el:"Ένα πολύγωνο αποτελείται μόνο από ευθύγραμμα τμήματα.",en:"A polygon is made only of straight line segments."}, type:"shape", answers:["0"], points:150 },
    { title:{el:"Η τελευταία ερώτηση",en:"The Final Question"}, text:{el:"Όσο περισσότερο αφαιρείς από εμένα, τόσο μεγαλύτερος γίνομαι. Τι είμαι;",en:"The more you take away from me, the bigger I become. What am I?"}, art:"◉　✦　◉", hint:{el:"Σκέψου τι δημιουργείται όταν αφαιρείς χώμα από το έδαφος.",en:"Think about what appears when you remove soil from the ground."}, type:"text", answers:["τρύπα","μια τρύπα","η τρύπα","hole","a hole"], points:200 }
  ];

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(key) || "null");
      return saved && typeof saved === "object" ? {...defaults, ...saved} : {...defaults};
    } catch(e) { return {...defaults}; }
  }
  function save() {
    try { localStorage.setItem(key, JSON.stringify(state)); } catch(e) {}
    updateProgress();
  }
  function t(name) {
    const lang = state.language === "en" ? "en" : "el";
    const dict = cfg.strings[lang];
    return dict[name] !== undefined ? dict[name] : name;
  }
  function setText(el, value) { if (el) el.textContent = value; }
  function renderLanguage() {
    root.querySelectorAll("[data-gm]").forEach(el => {
      const k = el.getAttribute("data-gm");
      setText(el, t(k));
    });
    $("gm-language").value = state.language;
    setText($("gm-hint"), "✧ " + t("hint"));
    setText($("gm-check"), t("check"));
    setText($("gm-next"), state.step === 2 ? t("finish") : t("next"));
    setText($("gm-home-button"), t("back"));
    setText($("gm-reset"), t("reset"));
    setText($("gm-start"), state.started && !state.completed ? t("continue") : t("start"));
    updateProgress();
  }
  function updateProgress() {
    const done = state.solved.filter(Boolean).length;
    const pct = Math.round(done / 3 * 100);
    setText($("gm-progress-label"), `${done} / 3`);
    setText($("gm-progress-points"), `${state.points} pts`);
    $("gm-progress-bar").style.width = pct + "%";
    setText($("gm-score"), state.points);
  }
  function show(view) {
    ["gm-home","gm-game","gm-complete"].forEach(id => $(id).classList.toggle("hidden", id !== view));
  }
  function start() {
    state.started = true;
    if (state.completed) { state.step = 0; state.completed = false; state.solved = [false,false,false]; state.hints=[false,false,false]; state.points=0; }
    save(); show("gm-game"); renderPuzzle();
  }
  function renderPuzzle() {
    const p = puzzles[state.step];
    selectedShape = -1; answered = !!state.solved[state.step];
    setText($("gm-puzzle-title"), p.title[state.language]);
    setText($("gm-puzzle-text"), p.text[state.language]);
    setText($("gm-puzzle-art"), p.art);
    setText($("gm-step"), state.step + 1);
    $("gm-feedback").textContent = answered ? t("correct") : "";
    $("gm-feedback").classList.toggle("good", answered);
    $("gm-answer-area").innerHTML = "";
    if (p.type === "shape") {
      const grid = document.createElement("div");
      grid.className = "gm-shape-grid";
      const shapes = state.language === "en" ? ["Circle","Triangle","Square","Star"] : ["Κύκλος","Τρίγωνο","Τετράγωνο","Αστέρι"];
      ["○","△","□","★"].forEach((shape,i) => {
        const b = document.createElement("button");
        b.type="button"; b.className="gm-shape-option"; b.setAttribute("aria-label", shapes[i]);
        b.innerHTML = `${shape}<span>${shapes[i]}</span>`;
        b.addEventListener("click", () => {
          if (answered) return;
          selectedShape=i;
          grid.querySelectorAll("button").forEach((x,j)=>x.classList.toggle("selected",j===i));
        });
        grid.appendChild(b);
      });
      $("gm-answer-area").appendChild(grid);
    } else {
      const input=document.createElement("input");
      input.type="text"; input.id="gm-answer"; input.className="gm-answer-input";
      input.placeholder=state.language==="en"?"Type your answer…":"Γράψε την απάντησή σου…";
      input.autocomplete="off"; input.setAttribute("aria-label", t("answer"));
      input.addEventListener("keydown",e=>{if(e.key==="Enter")checkAnswer();});
      $("gm-answer-area").appendChild(input);
      if (answered) input.disabled=true;
    }
    $("gm-hint").disabled = answered || state.hints[state.step];
    $("gm-hint").style.opacity = $("gm-hint").disabled ? ".5" : "1";
    $("gm-check").classList.toggle("hidden", answered);
    $("gm-next").classList.toggle("hidden", !answered);
    setText($("gm-next"), state.step===2?t("finish"):t("next"));
  }
  function checkAnswer() {
    if (answered) return;
    const p=puzzles[state.step];
    let answer="";
    if(p.type==="shape") answer=String(selectedShape);
    else answer=($("gm-answer").value||"").trim().toLocaleLowerCase(state.language==="el"?"el":"en").replace(/[.!?]/g,"");
    const correct=p.answers.some(a=>a.toLocaleLowerCase(state.language==="el"?"el":"en")===answer);
    if(correct) {
      answered=true; state.solved[state.step]=true; state.points+=p.points;
      save();
      $("gm-feedback").classList.add("good");
      setText($("gm-feedback"),t("correct"));
      $("gm-check").classList.add("hidden"); $("gm-next").classList.remove("hidden");
      if($("gm-answer")) $("gm-answer").disabled=true;
      $("gm-answer-area").querySelectorAll("button").forEach(b=>b.disabled=true);
      $("gm-hint").disabled=true;
      setText($("gm-next"),state.step===2?t("finish"):t("next"));
    } else {
      $("gm-feedback").classList.remove("good");
      setText($("gm-feedback"),t("wrong"));
    }
  }
  function showHint() {
    if(state.hints[state.step] || answered) return;
    state.hints[state.step]=true; save();
    const p=puzzles[state.step];
    setText($("gm-feedback"),p.hint[state.language]);
    $("gm-feedback").classList.remove("good");
    $("gm-hint").disabled=true; $("gm-hint").style.opacity=".5";
  }
  function next() {
    if(state.step<2) { state.step++; save(); renderPuzzle(); }
    else {
      state.completed=true; save(); show("gm-complete");
      setText($("gm-final-points"),state.points);
    }
  }
  function home() { show("gm-home"); renderLanguage(); }
  $("gm-language").addEventListener("change",e=>{state.language=e.target.value;save();renderLanguage();if(!$("gm-game").classList.contains("hidden"))renderPuzzle();});
  $("gm-start").addEventListener("click",start);
  $("gm-check").addEventListener("click",checkAnswer);
  $("gm-hint").addEventListener("click",showHint);
  $("gm-next").addEventListener("click",next);
  $("gm-home-button").addEventListener("click",home);
  $("gm-complete-home").addEventListener("click",home);
  $("gm-restart").addEventListener("click",start);
  $("gm-reset").addEventListener("click",()=>{
    if(window.confirm(t("resetConfirm"))) { state={...defaults,language:state.language}; save(); home(); }
  });

  renderLanguage();
  if(state.completed) { show("gm-complete"); setText($("gm-final-points"),state.points); }
  else if(state.started) { show("gm-game"); renderPuzzle(); }
  else show("gm-home");
})();