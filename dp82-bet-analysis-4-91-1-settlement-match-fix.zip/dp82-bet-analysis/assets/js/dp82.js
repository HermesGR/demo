/* Two helpers every block needs, defined once where every block can see them.
 *
 * They used to live inside one block, and a block is a closed scope — so the
 * coupon, which sits in a block of its own, was calling functions it could not
 * see. The first click threw a reference error, the handler stopped, and the
 * button looked dead with nothing reported anywhere. It worked for as long as
 * the coupon happened to share a block with them, and broke the moment new
 * blocks were added around it.
 */
function escapeHtml(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

function T(key, fallback) {
    var d = (typeof EMENU_DP82 !== 'undefined' && EMENU_DP82.i18n) ? EMENU_DP82.i18n : {};
    return d[key] || fallback || '';
  }

/* The coupon first, deliberately.
 *
 * This file holds six blocks that run one after another, and an error thrown
 * while any of them is setting up stops every block after it from registering
 * — its buttons simply stop responding, with nothing shown anywhere. The
 * coupon kept being the casualty because it sat in the middle and two blocks
 * were added above it. Nothing can precede it now, and it is guarded besides.
 */
/* Every word the panel shows comes from the server, in whichever language the
   reader chose. They were written into this file in Greek, so English
   translated the page and left the explanation — the part read most closely —
   in Greek underneath it. */
var DP82W = (typeof EMENU_DP82 !== 'undefined' && EMENU_DP82.words) ? EMENU_DP82.words : {};
function w(key, fallback) { return DP82W[key] || fallback; }

(function () {
  try {

  var opener = document.querySelector('.dp82-today-open');
  var sheet = document.getElementById('dp82-today');
  if (!opener || !sheet) return;

  var title = sheet.querySelector('.dp82-sheet-title');
  var body = sheet.querySelector('.dp82-sheet-body');
  var closer = sheet.querySelector('.dp82-sheet-close');
  var state = { sport: '', sportLabel: '', league: '' };

  /* Where the reader has been, so every screen can go back one step instead
     of closing the whole thing. Being thrown out to the start after looking at
     one team is the kind of small rudeness that stops people exploring. */
  var trail = [];

  function go(fn, label) {
    trail.push({ fn: fn, label: label });
    fn();
  }

  function back() {
    if (trail.length < 2) { hide(); return; }
    trail.pop();
    trail[trail.length - 1].fn();
  }

  function backBar() {
    if (trail.length < 2) return '';
    return '<button type="button" class="dp82-back-step">← Πίσω</button>';
  }

  function show() {
    sheet.hidden = false;
    document.body.classList.add('dp82-sheet-on');
    opener.classList.add('is-open');
  }
  function hide() {
    sheet.hidden = true;
    document.body.classList.remove('dp82-sheet-on');
    opener.classList.remove('is-open');
  }

  /* A request that fails must say so, not spin for ever.
     Reading the reply as JSON without checking what arrived meant that any
     non-JSON answer — an expired security token replying "-1", a PHP notice, a
     server error page — left the panel on "Loading…" with nothing to act on
     and no way back. The text is read first, then parsed, and whatever the
     server actually said is shown. */
  function ask(params) {
    var form = new URLSearchParams();
    form.append('action', 'emenu_dp82_today');
    form.append('nonce', EMENU_DP82.nonce);
    Object.keys(params).forEach(function (k) { form.append(k, params[k]); });
    return fetch(EMENU_DP82.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: form.toString()
    }).then(function (r) {
      return r.text().then(function (text) {
        try { return JSON.parse(text); }
        catch (e) {
          return { success: false, raw: text.slice(0, 300), status: r.status };
        }
      });
    }).catch(function (e) {
      return { success: false, raw: String(e), status: 0 };
    });
  }

  function failed(res) {
    var detail = res && res.raw ? res.raw : 'δεν ήρθε απάντηση';
    body.innerHTML = backBar() +
      '<p>Δεν ήταν δυνατή η φόρτωση.</p>' +
      '<p class="dp82-sheet-wait">' + escapeHtml(detail) + '</p>';
  }

  function loading(text) { body.innerHTML = '<p class="dp82-sheet-wait">' + text + '</p>'; }

  function chooseSport() {
    title.textContent = T('pick_sport', 'Διάλεξε άθλημα');
    loading(w('loading',T('loading', 'Φόρτωση…')));
    show();
    ask({ step: 'sports' }).then(function (res) {
      if (!res || !res.success) { failed(res); return; }
      if (!res.data.items.length) { body.innerHTML = '<p>Δεν υπάρχουν αγώνες σήμερα.</p>'; return; }
      var html = backBar() + '<div class="dp82-choices">';
      res.data.items.forEach(function (item) {
        /* A drawn icon rather than an image file: it takes the theme's
           colours, stays sharp on any screen and downloads nothing. */
        var icons = {
          football:   'M12 2a10 10 0 100 20 10 10 0 000-20zm0 4l3.5 2.5-1.3 4h-4.4l-1.3-4L12 6z',
          basketball: 'M12 2a10 10 0 100 20 10 10 0 000-20zM2 12h20M12 2c3 3 3 17 0 20M12 2c-3 3-3 17 0 20',
          tennis:     'M12 2a10 10 0 100 20 10 10 0 000-20zM5 5c4 3 4 11 0 14M19 5c-4 3-4 11 0 14',
          volleyball: 'M12 2a10 10 0 100 20 10 10 0 000-20zM12 12L4 8M12 12l8-4M12 12v10'
        };
        var d = icons[item.key] || icons.football;
        html += '<button type="button" class="dp82-choice" data-sport="' + item.key + '">' +
                '<span class="dp82-choice-main">' +
                  '<svg class="dp82-sport-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="' + d + '"/></svg>' +
                  '<span>' + item.label + '</span>' +
                '</span><b>' + item.count + '</b></button>';
      });
      body.innerHTML = html + '</div>';
    });
  }

  function chooseLeague(sport, label) {
    state.sport = sport; state.sportLabel = label;
    title.textContent = T('pick_league', 'Διάλεξε πρωτάθλημα');
    loading(w('loading',T('loading', 'Φόρτωση…')));
    ask({ step: 'leagues', sport: sport }).then(function (res) {
      if (!res || !res.success) { failed(res); return; }
      if (!res.data.items.length) {
        body.innerHTML = backBar() + '<p>Δεν υπάρχουν αγώνες σήμερα για αυτή την επιλογή.</p>'; return;
      }
      var html = backBar() + '<div class="dp82-choices">';
      res.data.items.forEach(function (item) {
        html += '<button type="button" class="dp82-choice" data-league="' +
                item.key.replace(/"/g, '&quot;') + '"><span class="dp82-choice-main">' +
                (item.flag ? '<span class="dp82-flag">' + item.flag + '</span>' : '') +
                '<span>' + escapeHtml(item.label) +
                (item.note ? ' <em>' + escapeHtml(item.note) + '</em>' : '') + '</span>' +
                '</span><b>' + item.count + '</b></button>';
      });
      body.innerHTML = html + '</div>';
    });
  }

  function showFixtures(league) {
    state.league = league;
    title.textContent = league;
    loading(w('loading',T('loading', 'Φόρτωση…')));
    ask({ step: 'fixtures', sport: state.sport, league: league }).then(function (res) {
      if (!res || !res.success) { failed(res); return; }
      if (!res.data.items.length) {
        body.innerHTML = backBar() + '<p>Δεν υπάρχουν αγώνες σήμερα για αυτή την επιλογή.</p>'; return;
      }
      var html = backBar() + '<ul class="dp82-fixtures">';
      res.data.items.forEach(function (m) {
        html += '<li><span class="dp82-fx-time">' + m.time + '</span>' +
                '<span class="dp82-fx-teams">' +
                  '<button type="button" class="dp82-team" data-team="' + m.home_id +
                    '" data-name="' + m.home.replace(/"/g, '&quot;') + '">' +
                    (m.home_logo ? '<img class="dp82-crest" loading="lazy" alt="" src="' +
                       m.home_logo.replace(/"/g, '&quot;') + '">' : '') +
                    escapeHtml(m.home) + '</button>' +
                  ' – ' +
                  '<button type="button" class="dp82-team" data-team="' + m.away_id +
                    '" data-name="' + m.away.replace(/"/g, '&quot;') + '">' +
                    (m.away_logo ? '<img class="dp82-crest" loading="lazy" alt="" src="' +
                       m.away_logo.replace(/"/g, '&quot;') + '">' : '') +
                    escapeHtml(m.away) + '</button>' +
                '</span>';
        /* All three, labelled. One bare figure was the home price with nothing
           saying so — a number with no question attached. Football shows 1, X
           and 2; the other sports have no draw and show two. A missing price
           leaves its slot empty rather than shifting the others along, which
           would make one read as another. */
        if (m.odds) {
          var legs = [['1', m.odds.home], ['X', m.odds.draw], ['2', m.odds.away]];
          html += '<span class="dp82-fx-odds">';
          legs.forEach(function (leg) {
            if (leg[0] === 'X' && (leg[1] === null || leg[1] === undefined)
                && m.odds.draw === undefined) return;
            html += '<i><b>' + leg[0] + '</b>' +
                    (leg[1] ? Number(leg[1]).toFixed(2) : '—') + '</i>';
          });
          html += '</span>';
        }
        html += '</li>';
        if (m.pick) {
          html += '<li class="dp82-fx-pick">' + m.pick +
                  (m.chance ? ' · ' + m.chance + '%' : '') + '</li>';
        }
      });
      body.innerHTML = html + '</ul>';
    });
  }

  function showTeam(teamId, name) {
    title.textContent = name;
    loading(w('loading',T('loading', 'Φόρτωση…')));
    var form = new URLSearchParams();
    form.append('action', 'emenu_dp82_team');
    form.append('nonce', EMENU_DP82.nonce);
    form.append('sport', state.sport);
    form.append('team', teamId);
    form.append('name', name);
    fetch(EMENU_DP82.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: form.toString()
    }).then(function (r) {
      return r.text().then(function (text) {
        try { return JSON.parse(text); }
        catch (e) { return { success: false, raw: text.slice(0, 300) }; }
      });
    }).catch(function (e) {
      return { success: false, raw: String(e) };
    }).then(function (res) {
      if (!res || !res.success) { failed(res); return; }
      if (!res.data.games.length) {
        /* A dead end still needs its way back. Being thrown out to the
           start because a team has no recorded matches is the moment a reader
           gives up on the whole feature. */
        body.innerHTML = backBar() +
          '<p>Δεν υπάρχουν καταγεγραμμένα παιχνίδια για αυτή την ομάδα.</p>'; return;
      }
      var html = backBar() + '<p class="dp82-sheet-sub">Τελευταία 10 παιχνίδια</p><ul class="dp82-history">';
      res.data.games.forEach(function (g) {
        html += '<li><span class="dp82-h-when">' + g.when + '</span>' +
                '<span class="dp82-h-opp">' + g.venue + ' · ' + g.opponent + '</span>' +
                '<span class="dp82-h-score">' + g.score +
                (g.half ? ' <em>(ημ. ' + g.half + ')</em>' : '') + '</span>';
        if (g.line) {
          html += '<span class="dp82-h-line ' + (g.over ? 'is-over' : 'is-under') + '">' + g.line + '</span>';
        }
        html += '<span class="dp82-h-res is-' + (g.result === 'Ν' ? 'win' : (g.result === 'Ι' ? 'draw' : 'loss')) +
                '">' + g.result + '</span></li>';
      });
      body.innerHTML = html + '</ul>';
    });
  }

  /* Listening on the document rather than on the button.
   *
   * This file now holds five separate blocks that run one after another, and
   * an error thrown while any of them is setting up stops every block after
   * it from ever registering — leaving its buttons dead with nothing shown
   * anywhere. Two blocks were added today, which is exactly when the coupon
   * stopped responding. A delegated listener does not care what ran before it
   * or whether the element existed at the time. */
  document.addEventListener('click', function (e) {
    var hit = e.target.closest ? e.target.closest('.dp82-today-open') : null;
    if (!hit) return;
    trail = [];
    go(chooseSport, 'άθλημα');
  });
  closer.addEventListener('click', hide);
  sheet.addEventListener('click', function (e) { if (e.target === sheet) hide(); });

  body.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('button') : null;
    if (!t) return;
    if (t.classList.contains('dp82-back-step')) { back(); return; }
    if (t.dataset.sport) {
      var sport = t.dataset.sport, label = t.textContent;
      go(function () { chooseLeague(sport, label); }, label);
      return;
    }
    if (t.dataset.league) {
      var league = t.dataset.league;
      go(function () { showFixtures(league); }, league);
      return;
    }
    if (t.dataset.team) {
      var id = t.dataset.team, nm = t.dataset.name;
      go(function () { showTeam(id, nm); }, nm);
    }
  });
  } catch (e) {
    /* One block failing must not silence the others. Before this, an
       error while any of them set up stopped every later block from
       registering, and its buttons simply stopped responding. */
    if (window.console && console.warn) console.warn('DP82 block failed:', e);
  }
})();

/* e-Menu CMS — Digital Menu
 * © 2026 Diamantis Panagiotis, ατομική επιχείρηση με διακριτικό τίτλο
 * «e-Menu CMS Digital Menu», Ρόδος, Ελλάδα. Με επιφύλαξη παντός δικαιώματος.
 * All rights reserved. Ιδιοκτησιακό λογισμικό — παραχωρείται με άδεια χρήσης,
 * δεν πωλείται. Proprietary software — licensed, not sold. Απαγορεύεται η
 * αντιγραφή και η μεταπώληση / Copying and reselling prohibited.
 * emenu.rho@gmail.com · https://e-menucms.gr
 */

/* DP82 AI BET ANALYSIS — the "Πώς προέκυψε" panel.
 *
 * The justification is not generated when the button is pressed. It is the
 * snapshot stored alongside the suggestion when it was made, fetched as-is.
 * That is the point: the explanation is the calculation, not a story told
 * afterwards.
 */
(function () {
  try {

  'use strict';

  if (typeof EMENU_DP82 === 'undefined') return;

  var cache = {};

  /* The wording comes from the server, in whichever language was chosen.
     Every label below used to be written here in Greek, so choosing English
     translated the page around a card that stayed Greek in the middle. */
  

  

  function render(data) {
    var html = '';

    html += '<h4>' + w('the_pick',T('the_pick', 'Η πρόταση')) + '</h4><dl>';
    html += '<dt>' + w('selection',T('selection', 'Επιλογή')) + '</dt><dd>' + escapeHtml(data.selection) + '</dd>';
    html += '<dt>' + w('model_p',T('model_prob', 'Πιθανότητα μοντέλου')) + '</dt><dd>' + escapeHtml(data.probability) + '%</dd>';
    if (data.odds) {
      html += '<dt>' + w('odds',T('odds', 'Απόδοση')) + '</dt><dd>' + escapeHtml(data.odds.toFixed(2)) +
              (data.book ? ' (' + escapeHtml(data.book) + ')' : '') + '</dd>';
    }
    if (data.implied !== null && data.implied !== undefined) {
      html += '<dt>' + w('implied',T('implied', 'Τεκμαρτή πιθανότητα απόδοσης')) + '</dt><dd>' + escapeHtml(data.implied) + '%</dd>';
    }
    if (data.edge !== null && data.edge !== undefined) {
      html += '<dt>' + w('edge',T('edge', 'Διαφορά μοντέλου – αγοράς')) + '</dt><dd>' +
              (data.edge > 0 ? '+' : '') + escapeHtml(data.edge) + '%</dd>';
    }
    html += '</dl>';

    if (data.factors && data.factors.length) {
      html += '<h4>' + w('the_data',T('the_data', 'Τα δεδομένα')) + '</h4><dl>';
      data.factors.forEach(function (factor) {
        html += '<dt>' + escapeHtml(factor.label) + '</dt><dd>' + escapeHtml(factor.value) + '</dd>';
      });
      html += '</dl>';
    }

    /* The two records that bear on the call, at the grounds that matter. A
       suggestion on the home side is a claim about them at home; showing their
       overall form would hide exactly what is being claimed. */
    /* The record that answers the question the suggestion asks.
       On "under 1.5 first-half goals" a win or a defeat is beside the point:
       what matters is how many goals each half actually held and whether the
       call would have come in. Every entry carries its date, because six
       letters in a row say nothing about which came first. */
    if (data.venue && (data.venue.home || data.venue.away)) {
      html += '<h4>' + w('record',T('venue_head', '')) + '</h4>';
      [['home', w('home_at',T('at_home', T('at_home', 'εντός έδρας')))], ['away', w('away_at',T('at_away', T('at_away', 'εκτός έδρας')))]].forEach(function (pair) {
        var rec = data.venue[pair[0]];
        if (!rec) return;
        var name = data.venue[pair[0] + '_name'] || '';
        html += '<div class="dp82-venue">';
        html += '<strong>' + escapeHtml(name) + '</strong> <span>' + pair[1] + '</span>';
        /* Both lines count for the suggestion, never against it. "Four times
           it did the thing that breaks this" makes the reader subtract in
           their head to reach the number they wanted; the same fact stated the
           other way needs no arithmetic at all. The opponent's line still
           belongs here — it is the only thing on the card arguing the other
           side — it simply says how often the suggestion survived them. */
        var kept = rec.ours === false ? (rec.played - rec.hits) : rec.hits;
        html += '<p class="dp82-venue-line"><b>' + escapeHtml(kept) + ' ' + w('of','στα') + ' ' +
                escapeHtml(rec.played) + '</b> ' +
                (rec.ours === false
                  ? w('not_stop',T('didnt_stop', ''))
                  : w('would_win',T('would_win', '')));
        if (rec.average !== null && rec.average !== undefined) {
          html += ' · μέσος όρος ' + escapeHtml(rec.average) + ' ' + escapeHtml(rec.label);
        }
        html += '</p>';
        /* Say what the record is drawn from. Anyone checking against a
           live-score site will count more matches than this, and the reason is
           coverage rather than error — naming the competitions turns an
           apparent gap into a stated scope. */
        if (rec.comps && rec.comps.length) {
          html += '<p class="dp82-venue-note">' + T('from_comps', 'από') + ' ' +
                  escapeHtml(rec.comps.join(', ')) + '</p>';
        }

        if (rec.values && rec.values.length) {
          html += '<p class="dp82-venue-note">πιο πρόσφατο πρώτα</p><div class="dp82-venue-form">';
          rec.values.forEach(function (v) {
            var good = (rec.ours === false) ? !v.hit : v.hit;
            html += '<span class="' + (good ? 'is-win' : 'is-loss') + '">' +
                    escapeHtml(v.text) + '<em>' + escapeHtml(v.when || '') + '</em></span>';
          });
          html += '</div>';
        }
        html += '</div>';
      });
    }

    if (data.steps && data.steps.length) {
      html += '<h4>' + w('the_calc',T('the_maths', 'Ο υπολογισμός')) + '' + (data.model ? ' (' + escapeHtml(data.model) + ')' : '') + '</h4><ol>';
      data.steps.forEach(function (step) { html += '<li>' + escapeHtml(step) + '</li>'; });
      html += '</ol>';
    }

    if (data.tempered) {
      html += '<p class="dp82-temper">' + escapeHtml(data.tempered) + '</p>';
    }
    if (data.gate) {
      html += '<p class="dp82-gate">' + escapeHtml(data.gate) + '</p>';
    }
    if (data.caveat) {
      html += '<p class="dp82-caveat">' + escapeHtml(data.caveat) + '</p>';
    }
    return html;
  }

  function load(button, panel) {
    var id = button.getAttribute('data-signal');

    if (cache[id]) {
      panel.innerHTML = cache[id];
      return;
    }

    panel.innerHTML = '<p>Φόρτωση…</p>';

    var body = new URLSearchParams();
    body.append('action', 'emenu_dp82_why');
    body.append('signal', id);
    body.append('nonce', EMENU_DP82.nonce);

    fetch(EMENU_DP82.ajax, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    })
      .then(function (response) { return response.json(); })
      .then(function (payload) {
        if (!payload || !payload.success) {
          var message = payload && payload.data && payload.data.message
            ? payload.data.message : w('failed',T('failed', 'Δεν ήταν δυνατή η φόρτωση.'));
          panel.innerHTML = '<p class="dp82-error">' + escapeHtml(message) + '</p>';
          return;
        }
        cache[id] = render(payload.data);
        panel.innerHTML = cache[id];
      })
      .catch(function () {
        panel.innerHTML = '<p class="dp82-error">Πρόβλημα σύνδεσης. Δοκίμασε ξανά.</p>';
      });
  }

  document.addEventListener('click', function (event) {
    var button = event.target.closest ? event.target.closest('.dp82-why') : null;
    if (!button) return;

    var panel = button.parentNode.querySelector('.dp82-reason');
    if (!panel) return;

    var open = !panel.hasAttribute('hidden');
    if (open) {
      panel.setAttribute('hidden', '');
      button.setAttribute('aria-expanded', 'false');
      button.textContent = w('why',T('why', 'Πώς προέκυψε'));
      return;
    }

    panel.removeAttribute('hidden');
    button.setAttribute('aria-expanded', 'true');
    button.textContent = w('hide',T('hide', 'Απόκρυψη'));
    load(button, panel);
  });
  } catch (e) {
    /* One block failing must not silence the others. Before this, an
       error while any of them set up stopped every later block from
       registering, and its buttons simply stopped responding. */
    if (window.console && console.warn) console.warn('DP82 block failed:', e);
  }
})();

/* Today's matches, in three steps.
 *
 * Sport, then competition, then the matches themselves — each step offering
 * only what the one before it leaves possible. A single list of everything we
 * hold would be hundreds of rows on a phone, which is not a schedule but a
 * wall. Tapping a team slides its last ten matches over the top.
 */


/* Choosing a sport for the suggestions.
 *
 * The eleven chips that used to sit under the tabs are here instead: press
 * Προτάσεις and pick. Only sports that actually have a live suggestion are
 * offered, because a filter leading to an empty list is a menu of
 * disappointments — and "all" comes first, since that is what most people
 * want.
 */
(function () {
  try {

  var tab = document.querySelector('.dp82-tips-open');
  var sheet = document.getElementById('dp82-today');
  if (!tab || !sheet) return;

  var title = sheet.querySelector('.dp82-sheet-title');
  var body = sheet.querySelector('.dp82-sheet-body');

  function esc(v) {
    return String(v === null || v === undefined ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  tab.addEventListener('click', function () {
    title.textContent = T('pick_sport', 'Διάλεξε άθλημα');
    body.innerHTML = '<p class="dp82-sheet-wait">Φόρτωση…</p>';
    sheet.hidden = false;
    document.body.classList.add('dp82-sheet-on');
    tab.classList.add('is-open');

    var form = new URLSearchParams();
    form.append('action', 'emenu_dp82_sports');
    form.append('nonce', EMENU_DP82.nonce);

    fetch(EMENU_DP82.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: form.toString()
    }).then(function (r) {
      return r.text().then(function (t) {
        try { return JSON.parse(t); } catch (e) { return { success: false, raw: t.slice(0, 300) }; }
      });
    }).catch(function (e) {
      return { success: false, raw: String(e) };
    }).then(function (res) {
      if (!res || !res.success) {
        body.innerHTML = '<p>Δεν ήταν δυνατή η φόρτωση.</p>' +
          '<p class="dp82-sheet-wait">' + esc(res && res.raw ? res.raw : '') + '</p>';
        return;
      }
      /* Always the suggestions. This carried the current view, so choosing a
         sport from the history stayed in the history — and since the tab that
         opened the chooser is the way back to the suggestions, there was no
         way back at all. A tab named Προτάσεις leads to Προτάσεις. */
      var view = 'open';
      var html = '<div class="dp82-choices">';
      res.data.items.forEach(function (item) {
        var url = new URL(window.location.href);
        url.searchParams.set('view', view);
        if (item.key) url.searchParams.set('sport', item.key);
        else url.searchParams.delete('sport');
        html += '<a class="dp82-choice" href="' + esc(url.toString()) + '">' +
                '<span>' + esc(item.label) + '</span><b>' + esc(item.count) + '</b></a>';
      });
      body.innerHTML = html + '</div>';
    });
  });
  } catch (e) {
    /* One block failing must not silence the others. Before this, an
       error while any of them set up stopped every later block from
       registering, and its buttons simply stopped responding. */
    if (window.console && console.warn) console.warn('DP82 block failed:', e);
  }
})();

/* Choosing a sport, from the Προτάσεις tab.
 *
 * The eleven chips that used to sit under the tabs are here instead: pressed
 * for, rather than occupying four lines of every visit whether wanted or not.
 * Only sports that actually have a suggestion are offered — a menu of empty
 * lists is worse than no menu.
 */






/* Telling the panel what is being looked at.
 *
 * One report when the page opens, and one for each thing pressed. No cookie of
 * ours and nothing identifying is sent — the server turns the request into a
 * daily handle and keeps only that. Failures are ignored on purpose: a
 * statistic is never worth interrupting somebody's reading for.
 */
(function () {
  try {

  if (typeof EMENU_DP82 === 'undefined') return;

  function ping(what, detail) {
    var form = new URLSearchParams();
    form.append('action', 'emenu_dp82_ping');
    form.append('nonce', EMENU_DP82.nonce);
    form.append('what', what);
    if (detail) form.append('detail', String(detail).slice(0, 120));
    fetch(EMENU_DP82.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: form.toString(), keepalive: true
    }).catch(function () {});
  }

  ping('page');

  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('button, a') : null;
    if (!el) return;
    if (el.classList.contains('dp82-why')) { ping('why'); return; }
    if (el.classList.contains('dp82-today-open')) { ping('coupon'); return; }
    if (el.classList.contains('dp82-tips-open')) { ping('sports_menu'); return; }
    if (el.dataset && el.dataset.sport) { ping('sport', el.dataset.sport); return; }
    if (el.dataset && el.dataset.league) { ping('league', el.dataset.league); return; }
    if (el.dataset && el.dataset.team) { ping('team', el.dataset.name || ''); return; }
    if (el.closest('.dp82-tabs')) { ping('tab', (el.textContent || '').trim().slice(0, 40)); }
  });

  /* A quiet heartbeat while the tab is open, so "how many are here now" means
     people still reading rather than people who arrived and left. */
  setInterval(function () {
    if (!document.hidden) ping('here');
  }, 120000);
  } catch (e) {
    /* One block failing must not silence the others. Before this, an
       error while any of them set up stopped every later block from
       registering, and its buttons simply stopped responding. */
    if (window.console && console.warn) console.warn('DP82 block failed:', e);
  }
})();

/* Sending a message to the admin.
 *
 * Name and address are required and checked here as well as on the server —
 * not to be officious, but because a suggestion nobody can reply to is a
 * suggestion nobody can act on, and finding that out after pressing send is
 * worse than being told before.
 */
(function () {
  try {

  /* ΟΛΑ τα κουμπιά, όχι μόνο το πρώτο.
     Το querySelector έπιανε ένα· από τη στιγμή που το ίδιο κουμπί υπάρχει
     και μέσα στο κλείδωμα των σημερινών δελτίων, το δεύτερο δεν άνοιγε
     τίποτα και έμοιαζε χαλασμένο. */
  var openers = document.querySelectorAll('.dp82-contact-open');
  var opener = openers[0];
  var sheet = document.getElementById('dp82-contact');
  if (!openers.length || !sheet) return;

  var closer = sheet.querySelector('.dp82-sheet-close');
  var said = sheet.querySelector('.dp82-contact-said');

  function show() { sheet.hidden = false; document.body.classList.add('dp82-sheet-on'); }
  function hide() { sheet.hidden = true; document.body.classList.remove('dp82-sheet-on'); }

  function tell(text, ok) {
    said.hidden = false;
    said.textContent = text;
    said.className = 'dp82-contact-said ' + (ok ? 'is-ok' : 'is-bad');
  }

  openers.forEach(function (b) { b.addEventListener('click', show); });
  closer.addEventListener('click', hide);
  sheet.addEventListener('click', function (e) { if (e.target === sheet) hide(); });

  sheet.querySelector('.dp82-contact-send').addEventListener('click', function () {
    var name = (document.getElementById('dp82-c-name').value || '').trim();
    var mail = (document.getElementById('dp82-c-email').value || '').trim();
    var body = (document.getElementById('dp82-c-body').value || '').trim();

    if (!name || !body) { tell(T('contact_need', 'Χρειάζονται όνομα και μήνυμα.'), false); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) {
      tell(T('contact_mail', 'Το e-mail δεν φαίνεται σωστό.'), false); return;
    }

    var form = new URLSearchParams();
    form.append('action', 'emenu_dp82_message');
    form.append('nonce', EMENU_DP82.nonce);
    form.append('name', name);
    form.append('email', mail);
    form.append('body', body);

    tell(T('loading', 'Φόρτωση…'), true);

    fetch(EMENU_DP82.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: form.toString()
    }).then(function (r) {
      return r.text().then(function (t) {
        try { return JSON.parse(t); } catch (e) { return { success: false }; }
      });
    }).then(function (res) {
      if (res && res.success) {
        tell(T('contact_done', 'Το μήνυμα στάλθηκε. Ευχαριστώ.'), true);
        document.getElementById('dp82-c-body').value = '';
      } else {
        var msg = res && res.data && res.data.message ? res.data.message
                : T('contact_fail', 'Δεν στάλθηκε. Δοκίμασε ξανά.');
        tell(msg, false);
      }
    });
  });
  } catch (e) {
    /* One block failing must not silence the others. Before this, an
       error while any of them set up stopped every later block from
       registering, and its buttons simply stopped responding. */
    if (window.console && console.warn) console.warn('DP82 block failed:', e);
  }
})();

/* Opening the terms.
 *
 * Each sheet on this page owns only its own element. Three of them share a
 * class now — the coupon, the contact form and this — and a handler that
 * reached for ".dp82-sheet" generally would close whichever it found first.
 */
(function () {
  try {

  var opener = document.querySelector('.dp82-policy-open');
  var sheet = document.getElementById('dp82-policy');
  if (!opener || !sheet) return;

  var closer = sheet.querySelector('.dp82-sheet-close');

  opener.addEventListener('click', function () {
    sheet.hidden = false;
    document.body.classList.add('dp82-sheet-on');
  });
  closer.addEventListener('click', function () {
    sheet.hidden = true;
    document.body.classList.remove('dp82-sheet-on');
  });
  sheet.addEventListener('click', function (e) {
    if (e.target === sheet) {
      sheet.hidden = true;
      document.body.classList.remove('dp82-sheet-on');
    }
  });
  } catch (e) {
    /* One block failing must not silence the others. Before this, an
       error while any of them set up stopped every later block from
       registering, and its buttons simply stopped responding. */
    if (window.console && console.warn) console.warn('DP82 block failed:', e);
  }
})();

/* The Bombs block is gone.
 *
 * It rendered its own sheet, its own card and its own explanation — three
 * copies of things the page already had, which is how one of them showed the
 * recent form and the other came out empty. Bombs are a view now, through the
 * same renderer as the suggestions, so there is nothing left here to keep in
 * step.
 */


/* ── ΣΥΛΛΟΓΟΙ ────────────────────────────────────────────────────────────────
   Άθλημα, πρωτάθλημα, σύλλογοι — και θεατής με δική μας μπάρα.

   Όλα τα δεδομένα είναι ήδη στη σελίδα· εδώ γίνεται μόνο εμφάνιση και
   απόκρυψη. Κανένα αίτημα στον διακομιστή για κάτι που δεν αλλάζει.
   ────────────────────────────────────────────────────────────────────────── */
(function () {
  var root = document.querySelector('.dp82-clubs');
  if (!root) return;

  var pick   = root.querySelector('.dp82-clubs-pick');
  var viewer = document.getElementById('dp82-viewer');
  var frame  = viewer ? viewer.querySelector('.dp82-viewer-frame') : null;
  var vname  = viewer ? viewer.querySelector('.dp82-viewer-name') : null;
  var vout   = viewer ? viewer.querySelector('.dp82-viewer-out') : null;

  /* Οι επιλογές κρατιούνται σε πίνακα και ξαναχτίζονται.
     Το «hidden» σε <option> δεν το σέβονται όλοι οι browsers — σε παλιό
     Safari η κρυμμένη επιλογή παραμένει επιλέξιμη. Η αφαίρεση και η
     επανατοποθέτηση δουλεύει παντού. */
  var everyOption = [];
  if (pick) {
    Array.prototype.forEach.call(pick.options, function (o) {
      everyOption.push({ value: o.value, text: o.textContent,
                         sport: o.getAttribute('data-for') });
    });
  }

  function showLeague(key) {
    root.querySelectorAll('.dp82-clubs-list').forEach(function (d) {
      d.hidden = (d.getAttribute('data-league') !== key);
    });
  }

  function showSport(sport) {
    root.querySelectorAll('[data-role="sport"] button').forEach(function (b) {
      b.classList.toggle('is-on', b.getAttribute('data-sport') === sport);
    });

    if (!pick) return;

    pick.innerHTML = '';
    var first = '';

    everyOption.forEach(function (o) {
      if (o.sport !== sport) return;
      var el = document.createElement('option');
      el.value = o.value;
      el.textContent = o.text;
      pick.appendChild(el);
      if (!first) first = o.value;
    });

    pick.value = first;
    showLeague(first);
  }

  root.addEventListener('click', function (ev) {
    var sb = ev.target.closest ? ev.target.closest('[data-sport]') : null;
    if (sb) { showSport(sb.getAttribute('data-sport')); return; }

    var club = ev.target.closest ? ev.target.closest('.dp82-club') : null;
    if (!club || !viewer || !frame) return;

    /* Το πλαίσιο πρώτα, το άνοιγμα σε νέα καρτέλα ως διέξοδος.
       Πολλά επίσημα σάιτ απαγορεύουν την ενσωμάτωση και ο browser το
       επιβάλλει — δεν παρακάμπτεται. Εκεί ο χρήστης βλέπει κενό πλαίσιο και
       έχει το κουμπί δίπλα του. */
    ev.preventDefault();

    var url = club.getAttribute('href');
    if (vname) vname.textContent = club.getAttribute('data-name') || '';
    if (vout)  vout.setAttribute('href', url);

    frame.setAttribute('src', url);
    viewer.hidden = false;
    document.body.style.overflow = 'hidden';
  });

  if (pick) {
    pick.addEventListener('change', function () { showLeague(pick.value); });
  }

  if (viewer) {
    viewer.addEventListener('click', function (ev) {
      if (!ev.target.closest || !ev.target.closest('.dp82-viewer-back')) return;
      viewer.hidden = true;
      if (frame) frame.setAttribute('src', 'about:blank');
      document.body.style.overflow = '';
    });
  }

  /* Αρχική κατάσταση: ποδόσφαιρο, πρώτο πρωτάθλημα — δηλαδή Ελλάδα. */
  showSport('football');
})();

/* ── ΠΟΝΤΑΡΙΣΜΑ ΑΝΑ ΔΕΛΤΙΟ ───────────────────────────────────────────────────
   Ο συνδεδεμένος ορίζει ποσό σε κάθε δελτίο· το ταμείο του υπολογίζεται από
   αυτά. Αποθηκεύεται στον ΛΟΓΑΡΙΑΣΜΟ, όχι στη συσκευή: το ίδιο ταμείο σε
   κινητό και υπολογιστή, και καθαρισμός του browser δεν το σβήνει.
   ────────────────────────────────────────────────────────────────────────── */
(function () {
  var cfg = window.EMENU_DP82 || {};
  if (!cfg.stakeNonce) return;   /* ανώνυμος: δεν υπάρχει πού να σωθεί */

  document.addEventListener('change', function (ev) {
    var sel = ev.target;
    if (!sel.matches || !sel.matches('.dp82-stake select')) return;

    var body = new URLSearchParams();
    body.set('action', 'emenu_dp82_stake');
    body.set('nonce', cfg.stakeNonce);
    body.set('parlay', sel.getAttribute('data-parlay') || '0');
    body.set('stake', sel.value);

    sel.disabled = true;

    fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function () {
        /* Η σελίδα ξαναφορτώνει: το ταμείο και το πλακίδιο υπολογίζονται
           στον διακομιστή, και μια οθόνη που δείχνει παλιό ταμείο δίπλα σε
           νέο ποντάρισμα είναι χειρότερη από μια στιγμή αναμονής. */
        window.location.reload();
      })
      .catch(function () { sel.disabled = false; });
  });
})();

/* ── ΔΙΚΗ ΣΟΥ ΑΠΟΔΟΣΗ ΑΝΑ ΣΚΕΛΟΣ ────────────────────────────────────────────
   Από γραφείο σε γραφείο οι τιμές διαφέρουν. Το ταμείο πρέπει να δείχνει τι
   πλήρωσε ο χρήστης, όχι τι έδινε ο πάροχος που έτυχε να ρωτηθεί.
   ────────────────────────────────────────────────────────────────────────── */
(function () {
  var cfg = window.EMENU_DP82 || {};
  if (!cfg.stakeNonce) return;

  var asking = false;

  document.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.dp82-odds-edit') : null;
    if (!btn || asking) return;

    ev.preventDefault();
    ev.stopPropagation();

    /* Το prompt είναι απλό και δουλεύει παντού. Ένα πεδίο μέσα στην κάρτα θα
       χρειαζόταν δικό του κλείσιμο, δική του ακύρωση και δική του στοίχιση σε
       κάθε ένα από τα δεκατέσσερα θέματα. */
    asking = true;

    var now = btn.getAttribute('data-now') || '';
    var ask = window.prompt(
      (cfg.i18n && cfg.i18n.oddsAsk) ? cfg.i18n.oddsAsk : 'Απόδοση', now);

    asking = false;

    if (ask === null) return;   /* ακύρωση: τίποτα δεν αλλάζει */

    var body = new URLSearchParams();
    body.set('action', 'emenu_dp82_odds');
    body.set('nonce', cfg.stakeNonce);
    body.set('leg', btn.getAttribute('data-leg') || '0');
    body.set('price', ask.trim());

    btn.disabled = true;

    fetch(cfg.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function () { window.location.reload(); })
      .catch(function () { btn.disabled = false; });
  });
})();

/* ── ΖΩΝΤΑΝΑ ΣΚΟΡ ─────────────────────────────────────────────────────────
   Γράφει το τρέχον σκορ πάνω στα σκέλη που παίζονται. Τα βρίσκει από το
   data-fx, όχι από τα ονόματα των ομάδων: τα ονόματα γράφονται αλλιώς σε
   κάθε πηγή και το ταίριασμα με κείμενο θα έσπαγε στην πρώτη διαφορά.

   Ρωτάει μόνο αν η σελίδα έχει όντως σκέλος σε αναμονή. Σε σελίδα χωρίς
   τέτοιο — ιστορικό, σύλλογοι — δεν στέλνει τίποτα. */
(function () {
  var D = window.EMENU_DP82 || {};
  if (!D.live || !D.live.on || !D.ajax) return;

  function liveNodes() {
    return document.querySelectorAll('.dp82-leg-wait[data-fx]');
  }

  function livePaint(map) {
    var nodes = liveNodes(), i, fx, sc, txt;

    for (i = 0; i < nodes.length; i++) {
      fx = nodes[i].getAttribute('data-fx');
      sc = map[fx];
      if (!sc) continue;

      txt = sc[0] + '-' + sc[1];
      /* Το σημάδι του λεπτού μπαίνει ΜΟΝΟ σε αριθμό. Το μπάσκετ στέλνει
         λέξη κατάστασης — «HT», «Q3» — και το «HT′» δεν σημαίνει τίποτα. */
      if (sc[2] !== '' && sc[2] !== null) {
        txt += ' · ' + sc[2] + (/^[0-9]+$/.test(String(sc[2])) ? '′' : '');
      }

      /* Το σκορ ημιχρόνου, όταν υπάρχει. Στο «0-1 · 63΄ (ΗΧ 0-0)» φαίνεται
         αμέσως ότι το γκολ μπήκε στο δεύτερο ημίχρονο — που για αγορά
         πρώτου ημιχρόνου είναι όλη η απάντηση. */
      if (sc.length > 4 && sc[3] !== '' && sc[4] !== '') {
        txt += ' (\u0397\u03a7 ' + sc[3] + '-' + sc[4] + ')';
      }

      nodes[i].textContent = txt;
      nodes[i].className = 'dp82-leg-live';
    }
  }

  function livePull() {
    if (!liveNodes().length) return;

    /* fetch, όπως κάθε άλλη κλήση αυτού του αρχείου. */
    var body = new FormData();
    body.append('action', 'emenu_dp82_live');

    fetch(D.ajax, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (r) {
        if (r && r.success && r.data && r.data.scores) livePaint(r.data.scores);
      })
      .catch(function () { /* σιωπηλά: μια χαμένη ανανέωση δεν είναι σφάλμα */ });
  }

  if (!liveNodes().length) return;

  livePull();
  setInterval(livePull, Math.max(30, parseInt(D.live.every, 10) || 900) * 1000);
})();
