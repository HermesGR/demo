<?php
/**
 * e-Menu CMS — Digital Menu
 *
 * © 2026 Diamantis Panagiotis, ατομική επιχείρηση με διακριτικό τίτλο
 * «e-Menu CMS Digital Menu», Ρόδος, Ελλάδα.
 * Με επιφύλαξη παντός δικαιώματος. All rights reserved.
 *
 * ΙΔΙΟΚΤΗΣΙΑΚΟ ΚΑΙ ΕΜΠΙΣΤΕΥΤΙΚΟ. Το λογισμικό παραχωρείται με άδεια χρήσης,
 * δεν πωλείται. Απαγορεύεται η αντιγραφή, τροποποίηση, δημοσίευση, διανομή,
 * περαιτέρω παραχώρηση, μεταπώληση, αποσυμπίληση ή αντίστροφη μηχανίκευση
 * οποιουδήποτε μέρους του, χωρίς προηγούμενη έγγραφη άδεια του δικαιούχου.
 * Η συνδρομή παρέχει δικαίωμα ΧΡΗΣΗΣ στο συμφωνημένο κατάστημα και για τη
 * συμφωνημένη περίοδο, και τίποτε άλλο. Κάθε παράβαση θα διώκεται στο
 * πλήρες εύρος του Ν. 2121/1993 και της Οδηγίας 2009/24/ΕΚ.
 *
 * PROPRIETARY AND CONFIDENTIAL. This software is licensed, not sold.
 * Copying, modifying, publishing, distributing, sublicensing, reselling,
 * decompiling or reverse engineering any part of it, in whole or in part,
 * is prohibited without the prior written permission of the copyright
 * holder. A subscription grants the right to USE this software on the
 * agreed premises for the agreed period, and nothing more. Unauthorised
 * use will be pursued to the full extent of Greek Law 2121/1993 and EU
 * Directive 2009/24/EC.
 *
 * emenu.rho@gmail.com · https://e-menucms.gr
 */
/**
 * DP82 — basketball detail from sources that publish it for nothing.
 *
 * The free API-Sports plan serves no historical detail, which is what stopped
 * rebounds and assists. Basketball has an escape route football does not: the
 * competitions publish their own box scores without a key.
 *
 *   highlightly  340+ leagues in 50+ countries on one free key — Greece,
 *                Spain, Italy, Germany, France, Australia, Japan, China,
 *                Korea, NCAA and FIBA. The breadth answer.
 *   euroleague   EuroLeague and EuroCup from the competition's own API.
 *                Official and stable, seasons back to 2007.
 *   espn         ESPN's own undocumented JSON — no key, no quota, full box
 *                scores for the NBA, WNBA and both college divisions. North
 *                America only.
 *
 * stats.nba.com was tried and dropped. It answers 403 to requests from data
 * centre addresses, which is where a WordPress site lives, and ESPN covers the
 * same ground without the argument.
 *
 * FIBA LiveStats was tried and dropped. It carries dozens of leagues but
 * publishes no schedule, so every competition would have needed a game code
 * found by hand and pasted in — once per league, and again whenever the
 * pattern changed. A source that cannot find its own fixtures is a chore, not
 * a source.
 *
 * Each source proves itself on the Πηγές screen before anything is built on
 * it, and prints what actually came back when it cannot. A source that breaks
 * is marked broken and stops contributing; the markets resting on it disappear
 * rather than quietly reporting stale numbers. A missing market is a small
 * loss, a wrong one is not.
 */
if (!defined('ABSPATH')) exit;

final class EMenu_DP82_Hoops {

    const SOURCES_OPT = 'emenu_dp82_hoops_sources';
    const STATE_OPT   = 'emenu_dp82_hoops_state';

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'register_menu'], 20);
        add_action('admin_post_emenu_dp82_hoops_probe', [$this, 'handle_probe']);
        add_action('admin_post_emenu_dp82_hoops_save', [$this, 'handle_save']);
    }

    public static function sources() {
        return [
            'balldontlie' => [
                'label'    => 'BALLDONTLIE — NBA',
                'official' => true,
                'note'     => 'Δωρεάν πακέτο: NBA, NFL, MLB, Premier League. '
                            . 'Πέντε κλήσεις το λεπτό, οπότε ζητούνται λίγες μέρες ανά σάρωση.',
            ],

            'bigballs' => [
                'label'    => 'Big Balls — 844 πρωταθλήματα, 9 αθλήματα',
                'official' => true,
                'note'     => 'Δωρεάν 1.000 κλήσεις την ημέρα, 100 το λεπτό. '
                            . 'Μία κλήση φέρνει όλους τους αγώνες του αθλήματος.',
            ],

            'highlightly' => [
                'label'    => 'Highlightly — 340+ πρωταθλήματα',
                'official' => true,
                'note'     => 'Ένα δωρεάν κλειδί: Ελλάδα, Ισπανία, Ιταλία, Γερμανία, Γαλλία, Αυστραλία, '
                            . 'Ιαπωνία, Κίνα, Κορέα, NCAA, FIBA. 100 κλήσεις την ημέρα.',
            ],

            /* NHL removed.
             *
             * Its season starts in October, so in August it walks eighteen
             * days to be told nothing eighteen times — and that step is where
             * the scan stopped, every time, for a day. Ice hockey was never
             * asked for and nobody here follows it.
             *
             * It comes back by restoring these lines, in October, if anybody
             * wants it. */
            'espn' => [
                'label'    => 'ESPN — μπάσκετ, τένις, χόκεϊ, μπέιζμπολ, NFL',
                'official' => false,
                'note'     => 'Χωρίς κλειδί και χωρίς όριο. Πρόγραμμα και αποτελέσματα, με πλήρη '
                            . 'box score στο μπάσκετ. Δεν καλύπτει Ασία ή ευρωπαϊκά πρωταθλήματα.',
            ],
            'euroleague' => [
                'label'    => 'EuroLeague',
                'official' => true,
                'note'     => 'Επίσημο API της διοργάνωσης, πλήρη box score από το 2007.',
            ],
            'eurocup' => [
                'label'    => 'EuroCup',
                'official' => true,
                'note'     => 'Ίδιο API, άλλος κωδικός διοργάνωσης.',
            ],
        ];
    }

    /* ------------------------------------------------------------ settings */

    public function settings() {
        $saved = get_option(self::SOURCES_OPT, []);
        if (!is_array($saved)) $saved = [];
        return array_merge([
            'disabled' => [],   // the exception, not the rule
            'hl_key'   => '',

            /* Εναλλακτικές πηγές αγώνων, για όταν το Highlightly εξαντλήσει
               το ημερήσιο όριό του. Κενό σημαίνει «δεν χρησιμοποιείται» — δεν
               γίνεται καμία κλήση χωρίς κλειδί. */
            'bb_key'   => '',
            'bdl_key'  => '',
            'season'   => '',
        ], $saved);
    }

    public function enabled($key) {
        $s = $this->settings();
        return !in_array($key, (array) $s['disabled'], true);
    }

    private function state() {
        $st = get_option(self::STATE_OPT, []);
        return is_array($st) ? $st : [];
    }

    private function save_state($state) {
        update_option(self::STATE_OPT, $state, false);
    }

    /**
     * Write into the same log the scan panel shows.
     *
     * Added because "espn: 0" and "tennis: 0" have now been reported three
     * times without saying whether the request failed, returned nothing, or
     * returned something that was thrown away. A number with no account of
     * itself is not a diagnosis.
     */
    private function outcome($key, $summary) {
        if (class_exists('EMenu_DP82')) {
            $dp = EMenu_DP82::instance();
            if (method_exists($dp, 'record_outcome')) $dp->record_outcome($key, $summary);
        }
    }

    private function note($message) {
        $state = $this->state();
        if (!isset($state['log']) || !is_array($state['log'])) $state['log'] = [];
        $state['log'][] = ['time' => current_time('mysql'), 'text' => $message];
        if (count($state['log']) > 60) $state['log'] = array_slice($state['log'], -60);
        $this->save_state($state);

        if (class_exists('EMenu_DP82')) {
            $dp = EMenu_DP82::instance();
            if (method_exists($dp, 'external_log')) $dp->external_log($message);
        }
    }

    public function mark($key, $ok, $note = '') {
        $state = $this->state();
        $state['health'][$key] = ['ok' => (bool) $ok, 'note' => (string) $note, 'checked' => current_time('mysql')];
        $this->save_state($state);
    }

    public function health($key) {
        $state = $this->state();
        return isset($state['health'][$key]) ? $state['health'][$key] : null;
    }

    /* ---------------------------------------------------------------- http */

    /**
     * One request, with a wait short enough that the step survives it.
     *
     * This waited twenty-five seconds. The step's own budget is fifteen, and
     * that budget is checked between requests — so a single slow endpoint blew
     * past it before anything had a chance to look at the clock. Eighteen days
     * of a sport that is out of season is eighteen of those waits, which is
     * seven minutes, and PHP is allowed rather less: the scan died at whatever
     * step it happened to be on, with no error, and it looked like a different
     * fault every time it happened.
     *
     * Eight seconds. A feed that cannot answer in eight is a feed that is not
     * going to answer, and the day it is asked about is picked up on the next
     * run.
     */
    private function get($url, $headers = [], $ttl = HOUR_IN_SECONDS) {
        $agent = '';
        if (isset($headers['User-Agent'])) {
            $agent = $headers['User-Agent'];
            unset($headers['User-Agent']);
        }
        $cache_key = 'emenu_dp82_h_' . md5($url);
        $cached = get_transient($cache_key);
        if ($cached !== false) return $cached;

        $args = [
            'timeout' => 8,
            'headers' => array_merge(['Accept' => 'application/json'], $headers),
        ];
        // Passed as an argument, not a header: WordPress overwrites the header
        // with its own name, and statsapi.mlb.com answers 406 to that name.
        if ($agent !== '') $args['user-agent'] = $agent;
        $res = wp_remote_get($url, $args);
        if (is_wp_error($res)) return $res;

        $code = wp_remote_retrieve_response_code($res);
        $raw = wp_remote_retrieve_body($res);
        if ($code !== 200) return new WP_Error('dp82_hoops_http', 'Απάντηση ' . $code);
        $body = json_decode($raw, true);
        if (!is_array($body)) return new WP_Error('dp82_hoops_json', 'Η απάντηση δεν ήταν JSON');

        set_transient($cache_key, $body, max(60, (int) $ttl));
        return $body;
    }

    /** Reach into a nested array by dotted path, without isset() stacks. */
    /**
     * One side's score, however this sport happens to report it.
     *
     * Team sports put a number in "score". Tennis does not — it carries
     * "linescores", one entry per set, and a "winner" flag. Reading only
     * "score" stored every finished tennis match with a null result, and the
     * form builder needs a result: it asks for matches where both scores are
     * present, found none, and reported 249 upcoming matches with no history
     * on either side.
     *
     * So the fixtures were all there and unusable. Sets won is the right
     * number for tennis — it is what the sport calls a score — and where even
     * that is missing, the winner flag gives 1–0, which is enough to know who
     * won and therefore enough to build form from.
     */
    /**
     * Fill in the scores that were stored as nothing. Once.
     *
     * A thousand finished tennis matches sit in the table with null scores,
     * because until this version the reader looked for a "score" field that
     * tennis does not send. Fixing the reader fixes what arrives next; it does
     * nothing for what already arrived, and the form builder needs the ones
     * already there — it asks for matches with both scores present, finds
     * none, and reports two hundred and forty-nine upcoming matches with no
     * history on either side.
     *
     * Waiting for the ordinary day-window to come round again would take
     * weeks. This walks the stored history once and asks ESPN for the days it
     * covers, bounded by the same step clock as everything else, so a slow
     * answer costs a few seconds rather than the run.
     */
    /**
     * A competitor's identifier, whatever the sport calls it.
     *
     * Teams have an id and it is used. Tennis players arrive with a name and
     * no id at the path ESPN documents, so the name becomes the key: folded
     * to lower case, stripped of accents and punctuation, spaces closed up.
     *
     * "Oleksandra Oliynykova" and "OLIYNYKOVA, Oleksandra" still differ — one
     * problem is not two — but the same feed spells a player the same way
     * every time, and that is all this needs to link a player to their own
     * past matches.
     *
     * Never returns empty. An empty key is what caused every tennis player to
     * share one record; a key derived from nothing at all is better spelled
     * out as unknown than left blank to collide with the next one.
     */
    /**
     * Which tour or competition an event belongs to.
     *
     * ESPN returns the same tennis on both the ATP and the WTA board, so the
     * URL that fetched it says nothing about whose draw it is. The event
     * itself usually carries a name — the tournament, or the league — and
     * that is the honest answer.
     *
     * Falls back to the label of the board that was asked for. Wrong
     * sometimes, which is where this started, but never empty.
     */
    private static function tour_name($event, $competition, $fallback) {
        foreach ([
            [$competition, 'type.abbreviation'],
            [$competition, 'type.text'],
            [$event, 'league.abbreviation'],
            [$event, 'league.name'],
            [$event, 'season.type.name'],
            [$event, 'name'],
        ] as $where) {
            $v = trim((string) self::pick_path($where[0], $where[1], ''));
            if ($v !== '') return $v;
        }
        return (string) $fallback;
    }

    private static function competitor_key($side) {
        $id = self::pick_path($side, 'team.id', '');
        if ($id !== '' && $id !== null) return (string) $id;

        $id = self::pick_path($side, 'athlete.id', '');
        if ($id !== '' && $id !== null) return (string) $id;

        $name = (string) self::pick_path($side, 'athlete.displayName',
                         self::pick_path($side, 'athlete.shortName',
                         self::pick_path($side, 'team.displayName', '')));

        $name = trim($name);
        if ($name === '') return 'unknown';

        if (function_exists('remove_accents')) $name = remove_accents($name);
        $name = strtolower($name);
        $name = preg_replace('/[^a-z0-9]+/', '', $name);

        return ($name === '') ? 'unknown' : 'n' . $name;
    }

    public function backfill_tennis_scores() {
        global $wpdb;

        if (get_option('emenu_dp82_tennis_scores') === '1') return 0;

        $fixtures = $wpdb->prefix . 'emenu_dp82_fixtures';

        /* Which days actually need it — not every day in the range. */
        $days = $wpdb->get_col(
            "SELECT DISTINCT DATE(kickoff) FROM $fixtures
              WHERE sport = 'tennis' AND finished = 1
                AND (home_score IS NULL OR away_score IS NULL)
           ORDER BY kickoff DESC LIMIT 6");

        if (!$days) {
            update_option('emenu_dp82_tennis_scores', '1', false);
            return 0;
        }

        /* Its own six seconds, and the step's clock left alone.
         *
         * step_begin() used to be called here, which reset the clock the main
         * ingestion then shares — so the repair spent the whole fifteen
         * seconds and the fetch that follows found nothing left and stopped
         * at once. Two jobs, one budget, and the second never ran.
         *
         * Six days a pass rather than forty, too. Forty days across two tours
         * is eighty requests at eight seconds each: a step that cannot finish
         * inside any sane limit, gets killed by the server halfway, and takes
         * the whole scan down with it — which is what "no heartbeat for half
         * an hour" was. Six days is a dozen requests and always returns.
         *
         * The rest is picked up next scan. It marks itself done only when
         * nothing is left, so nothing is skipped, only spread out. */
        $own_clock = microtime(true);
        $done = 0;

        foreach ($days as $day) {
            if ((microtime(true) - $own_clock) > 6) break;

            /* Same guard as the reader below: this runs first in the step, so
               a board held here is memory the reader does not get. */
            if (self::memory_tight()) break;

            foreach (['tennis/atp', 'tennis/wta'] as $league) {
                if ((microtime(true) - $own_clock) > 6) break 2;
                if (self::memory_tight()) break 2;

                $board = $this->espn_scoreboard($league, $day);
                if (is_wp_error($board)) continue;

                foreach ((array) self::pick_path($board, 'events', []) as $event) {
                    foreach ((array) self::pick_path($event, 'competitions', []) as $ci => $competition) {
                        $sides = isset($competition['competitors']) ? $competition['competitors'] : [];
                        if (count((array) $sides) < 2) continue;

                        $listed = array_values((array) $sides);
                        $hs = self::espn_score($listed[0]);
                        $as = self::espn_score($listed[1]);
                        if ($hs === null || $as === null) continue;

                        /* The same identifier the match was stored under.
                         *
                         * This used the event id, and the match was written
                         * with the competition id. In football they are the
                         * same thing and it never showed; in tennis an event
                         * is a day of a tournament holding forty matches, so
                         * the two never matched and the update touched no rows
                         * at all. Eleven hundred finished matches sat with no
                         * score through every run of this, and the form
                         * builder — which needs a result — found nothing to
                         * build from.
                         *
                         * Derived exactly as the writer derives it, index and
                         * all, so the two cannot drift apart again. */
                        $id = (string) (isset($competition['id'])
                            ? $competition['id']
                            : (isset($event['id']) ? $event['id'] . '-' . $ci : ''));
                        if ($id === '') continue;

                        $done += (int) $wpdb->query($wpdb->prepare(
                            "UPDATE $fixtures SET home_score = %d, away_score = %d
                              WHERE sport = 'tennis' AND provider_id = %s
                                AND (home_score IS NULL OR away_score IS NULL)",
                            $hs, $as, $id));
                    }
                }
            }
        }

        /* Only marked finished when there is nothing left, so a run that ends
           on the clock is picked up by the next one rather than abandoned. */
        $left = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM $fixtures
              WHERE sport = 'tennis' AND finished = 1
                AND (home_score IS NULL OR away_score IS NULL)");
        if ($left === 0) update_option('emenu_dp82_tennis_scores', '1', false);

        return $done;
    }

    private static function espn_score($side) {
        if (isset($side['score']) && $side['score'] !== '') return (int) $side['score'];

        if (!empty($side['linescores']) && is_array($side['linescores'])) {
            $sets = 0;
            foreach ($side['linescores'] as $set) {
                if (isset($set['winner']) && $set['winner']) $sets++;
            }
            if ($sets > 0) return $sets;
        }

        if (isset($side['winner'])) return $side['winner'] ? 1 : 0;

        return null;
    }

    private static function pick_path($arr, $path, $fallback = null) {
        $cur = $arr;
        foreach (explode('.', (string) $path) as $step) {
            if (!is_array($cur) || !array_key_exists($step, $cur)) return $fallback;
            $cur = $cur[$step];
        }
        return $cur;
    }

    /**
     * Find team totals anywhere in a response.
     *
     * Written after three attempts at guessing EuroLeague's box-score shape.
     * Rather than assume a path, this walks the whole structure looking for any
     * node that carries several recognisable statistics at once, and takes the
     * first two it finds as the two sides. It survives a feed reorganising
     * itself, which the hard-coded readers did not.
     */
    public static function deep_totals($data) {
        $names = [
            'rebounds'  => ['totalrebounds', 'rebounds', 'totreb', 'reb', 'tot_reb'],
            'assists'   => ['assistances', 'assists', 'ast'],
            'steals'    => ['steals', 'stl'],
            'blocks'    => ['blocksfavour', 'blocks', 'blk'],
            'turnovers' => ['turnovers', 'tov', 'to'],
            'fouls'     => ['foulscommited', 'foulscommitted', 'personalfouls', 'fouls', 'pf'],
            'points'    => ['points', 'pts', 'score'],
        ];

        $found = [];

        $visit = function ($node) use (&$visit, &$found, $names) {
            if (!is_array($node) || count($found) >= 2) return;

            // A flat map of this node's own scalar keys, lower-cased.
            $flat = [];
            foreach ($node as $k => $v) {
                if (is_scalar($v) && is_numeric($v)) $flat[strtolower((string) $k)] = (float) $v;
            }
            // Some feeds put them as {type|name, value} pairs instead.
            foreach ($node as $v) {
                if (!is_array($v)) continue;
                foreach (['type', 'name', 'displayName', 'label'] as $label_key) {
                    if (isset($v[$label_key]) && isset($v['value']) && is_numeric($v['value'])) {
                        $flat[strtolower((string) $v[$label_key])] = (float) $v['value'];
                    }
                }
            }

            $row = [];
            $hits = 0;
            foreach ($names as $metric => $candidates) {
                $row[$metric] = null;
                foreach ($candidates as $candidate) {
                    if (isset($flat[$candidate])) { $row[$metric] = $flat[$candidate]; $hits++; break; }
                }
            }
            // Three recognisable figures is enough to call it a totals block;
            // fewer and it is probably a period line or a single player.
            if ($hits >= 3 && $row['rebounds'] !== null) {
                $found[] = $row;
                return;
            }

            foreach ($node as $child) {
                if (is_array($child)) $visit($child);
                if (count($found) >= 2) return;
            }
        };

        $visit(is_array($data) ? $data : []);
        if (count($found) < 2) return null;
        return ['home' => $found[0], 'away' => $found[1]];
    }

    private static function pick($row, array $keys) {
        foreach ($keys as $key) {
            if (isset($row[$key]) && is_numeric($row[$key])) return (float) $row[$key];
        }
        return null;
    }

    /**
     * Total games in a tennis scoreline. "6-4 7-6(5) 3-6" is thirty-six games,
     * and tie-break points in brackets are not games — the market is over and
     * under total games, so this has to be exact rather than approximate.
     */
    public static function games_in_score($score) {
        $score = trim((string) $score);
        if ($score === '' || stripos($score, 'W/O') !== false || stripos($score, 'RET') !== false) return null;
        $score = preg_replace('/\([^)]*\)/', '', $score);
        if (!preg_match_all('/(\d+)\s*-\s*(\d+)/', $score, $sets, PREG_SET_ORDER)) return null;
        $total = 0;
        foreach ($sets as $set) $total += (int) $set[1] + (int) $set[2];
        return $total > 0 ? $total : null;
    }

    private static function unwrap($body) {
        if (is_array($body) && isset($body['data']) && is_array($body['data'])) return $body['data'];
        return $body;
    }

    private function season_code($competition) {
        $s = $this->settings();
        if (!empty($s['season'])) return $competition . $s['season'];
        $year = (int) wp_date('Y');
        if ((int) wp_date('n') < 8) $year--;
        return $competition . $year;
    }

    /* --------------------------------------------------------- highlightly */

    /**
     * Two addresses depending on where the key came from — their own site or
     * RapidAPI. Both are tried and the one that answers is remembered, so the
     * distinction never becomes someone else's problem.
     */
    private function hl_get($path, $args = [], $ttl = 3 * HOUR_IN_SECONDS) {
        $s = $this->settings();
        $key = trim((string) $s['hl_key']);
        if ($key === '') return new WP_Error('dp82_hl_nokey', 'Δεν έχει οριστεί κλειδί Highlightly.');

        // Both addresses want the same header name. The first attempt used
        // x-api-key, which is what the 403 was: the key was fine, the header
        // was invented. Taken from their documentation rather than guessed.
        $bases = [
            ['https://basketball.highlightly.net/', ['x-rapidapi-key' => $key]],
            ['https://basketball-highlights-api.p.rapidapi.com/', [
                'x-rapidapi-key'  => $key,
                'x-rapidapi-host' => 'basketball-highlights-api.p.rapidapi.com',
            ]],
        ];

        $state = $this->state();
        if (!empty($state['hl_base'])) {
            usort($bases, function ($a, $b) use ($state) {
                return ($b[0] === $state['hl_base'] ? 1 : 0) - ($a[0] === $state['hl_base'] ? 1 : 0);
            });
        }

        $last = null;
        foreach ($bases as $base) {
            $url = $base[0] . ltrim($path, '/');
            if ($args) $url = add_query_arg($args, $url);
            $body = $this->get($url, $base[1], $ttl);
            if (!is_wp_error($body)) {
                $state = $this->state();
                $state['hl_base'] = $base[0];
                $this->save_state($state);
                return $body;
            }
            $last = $body;
        }
        return $last;
    }

    public function hl_leagues() {
        return $this->hl_get('leagues', ['limit' => 100], DAY_IN_SECONDS);
    }

    public function hl_matches($date) {
        return $this->hl_get('matches', ['date' => wp_date('Y-m-d', strtotime($date)), 'limit' => 100]);
    }

    public function hl_match($id) {
        return $this->hl_get('matches/' . rawurlencode($id), [], DAY_IN_SECONDS);
    }

    /** Detail lives on its own route, not inside the match. */
    public function hl_stats($match_id) {
        return $this->hl_get('statistics/' . rawurlencode($match_id), [], DAY_IN_SECONDS);
    }

    /** Season totals per team, including the home and away split. */
    public function hl_team_stats($team_id, $from) {
        return $this->hl_get('teams/statistics/' . rawurlencode($team_id),
            ['fromDate' => wp_date('Y-m-d', strtotime($from))], 6 * HOUR_IN_SECONDS);
    }

    /**
     * Their statistics arrive as a list of display names and values rather
     * than named fields, so each metric is matched on the label. Matching is
     * loose because the labels vary between competitions.
     */
    public function hl_totals($stats) {
        $stats = self::unwrap($stats);
        if (!is_array($stats) || !$stats) return null;

        $find = function ($list, array $needles) {
            foreach ((array) $list as $entry) {
                if (!is_array($entry) || !isset($entry['displayName'])) continue;
                $label = mb_strtolower((string) $entry['displayName'], 'UTF-8');
                foreach ($needles as $needle) {
                    if (strpos($label, $needle) !== false && isset($entry['value']) && is_numeric($entry['value'])) {
                        return (float) $entry['value'];
                    }
                }
            }
            return null;
        };

        $out = [];
        foreach (array_values($stats) as $index => $team) {
            if (!is_array($team) || empty($team['statistics'])) continue;
            $list = $team['statistics'];
            $out[$index === 0 ? 'home' : 'away'] = [
                'rebounds'  => $find($list, ['rebound']),
                'assists'   => $find($list, ['assist']),
                'steals'    => $find($list, ['steal']),
                'blocks'    => $find($list, ['block']),
                'turnovers' => $find($list, ['turnover']),
                'fouls'     => $find($list, ['foul']),
                'points'    => $find($list, ['point']),
            ];
        }
        return $out ? $out : null;
    }

    /* ------------------------------------------------- official league APIs

     * Two feeds the leagues themselves publish, free and without a key.
     *
     * Both were suggested and both check out: they are the leagues' own
     * public endpoints, not scraped pages and not somebody's mirror, so there
     * is no licence question and nothing to be blocked for. They matter
     * because they serve past games — the thing every sport except football
     * has been missing, and the reason hockey and baseball have sat at zero
     * teams with form for weeks.
     */

    public function nhl_schedule($date) {
        return $this->get('https://api-web.nhle.com/v1/schedule/' . rawurlencode($date), [
            'User-Agent' => 'Mozilla/5.0 (compatible; DP82/1.0)',
            'Accept'     => 'application/json',
        ], 3 * HOUR_IN_SECONDS);
    }

    public function mlb_schedule($from, $to) {
        $url = add_query_arg(
            ['sportId' => 1, 'startDate' => $from, 'endDate' => $to],
            'https://statsapi.mlb.com/api/v1/schedule'
        );
        // 406 Not Acceptable: the endpoint refuses WordPress's own user agent.
        // It is not blocking us, it simply will not answer that name.
        return $this->get($url, [
            'User-Agent' => 'Mozilla/5.0 (compatible; DP82/1.0)',
            'Accept'     => 'application/json',
        ], 3 * HOUR_IN_SECONDS);
    }

    /** Both leagues, folded into the shape the rest of the module reads. */
    /**
     * How long one step of the scan is allowed to take.
     *
     * Every step walks a range of days and asks a provider about each one. In
     * season that is cheap; out of season it is a series of requests that
     * return nothing slowly, and the scan stops on it — the NHL in August, the
     * NBA in July, baseball in January. The queue then reports "no sign of
     * life" and waits for somebody to press the button.
     *
     * Fifteen seconds, checked between days rather than mid-request. Nothing
     * is lost when it fires: the days already read are stored, and the next
     * run continues from where this one stopped. A step that ends early is a
     * scan that finishes; a step that runs forever is a scan that never does.
     */
    private $step_started = 0;

    /**
     * Whether this step has had its share of the request.
     *
     * Fifteen seconds, measured from the first time it is asked. Every loop
     * that fetches anything consults it, and the answer is the same for all
     * of them — so a step cannot spend its budget in one loop and then start
     * another.
     *
     * The number matters less than the checking. A step with no clock does
     * not fail slowly; it fails by never returning, and the scan sits on the
     * same number until somebody presses skip. That is how baseball and then
     * the NFL stopped every scan on this site.
     */
    /**
     * A breadcrumb, written before the thing that might not survive.
     *
     * The journal is written when a job finishes. A job killed halfway — out
     * of memory, out of time, whatever the server decides — writes nothing at
     * all, and the export shows the last successful step as if nothing had
     * been attempted since. Three explanations have been tried against that
     * silence and none of them fitted, because the evidence was never there.
     *
     * This drops a note first and clears it on success. A note still sitting
     * there is the last thing that was tried, and it survives the process
     * being killed because it is written before the attempt, not after.
     */
    /**
     * Whether there is room left to read another large response.
     *
     * PHP does not warn before it stops: the request is killed mid-statement
     * and nothing after it runs, including whatever would have recorded why.
     * So the question has to be asked before the allocation, not after.
     *
     * Eighty per cent of the limit, which on a hundred and twenty-eight
     * megabyte site leaves twenty-five for the response being fetched — more
     * than any single board has ever needed.
     */
    private static function memory_tight() {
        $limit = trim((string) ini_get('memory_limit'));
        if ($limit === '' || $limit === '-1') return false;

        $unit = strtoupper(substr($limit, -1));
        $bytes = (float) $limit;
        if ($unit === 'G')      $bytes *= 1024 * 1024 * 1024;
        elseif ($unit === 'M')  $bytes *= 1024 * 1024;
        elseif ($unit === 'K')  $bytes *= 1024;

        if ($bytes <= 0) return false;

        return memory_get_usage(true) > ($bytes * 0.8);
    }

    private function crumb($what) {
        update_option('emenu_dp82_crumb', [
            'what' => (string) $what,
            'at'   => time(),
            'mem'  => (int) (memory_get_usage(true) / 1048576),
            'peak' => (int) (memory_get_peak_usage(true) / 1048576),
        ], false);
    }

    private function crumb_done() {
        update_option('emenu_dp82_crumb', '', false);
    }

    private function step_deadline_passed() {
        if (!$this->step_started) {
            $this->step_started = time();
            return false;
        }
        return (time() - $this->step_started) > 15;
    }

    private function step_begin() {
        $this->step_started = time();
    }

    public function ingest_league_api($key, $days_back = 21) {
        $stored = 0;
        $skipped = 0;

        if ($key === 'nhl') {
            // One call returns a week, so a fortnight costs three requests.
            $this->step_begin();
            for ($offset = -$days_back; $offset <= 7; $offset += 7) {
                if ($this->step_deadline_passed()) break;
                $day = wp_date('Y-m-d', time() + $offset * DAY_IN_SECONDS);
                $body = $this->nhl_schedule($day);
                if (is_wp_error($body)) { $skipped++; continue; }
                foreach ((array) self::pick_path($body, 'gameWeek', []) as $week_day) {
                    foreach ((array) self::pick_path($week_day, 'games', []) as $game) {
                        $id = (string) self::pick_path($game, 'id', '');
                        if ($id === '') { $skipped++; continue; }

                    /* A tennis draw is published a round ahead with "TBD"
                       standing in for whoever wins the match before. Storing
                       those fills the table with placeholders that can never
                       be modelled and can never be played. */
                    $names_check = ($home_name_raw ?? '') . ' ' . ($away_name_raw ?? '');
                    if (stripos($names_check, 'TBD') !== false) { $skipped++; continue; }
                        $state = strtoupper((string) self::pick_path($game, 'gameState', ''));
                        $hs = self::pick_path($game, 'homeTeam.score');
                        $as = self::pick_path($game, 'awayTeam.score');
                        $done = in_array($state, ['OFF', 'FINAL'], true) && is_numeric($hs) && is_numeric($as);
                        if ($done && $this->already_have('hockey', 'nhl', $id)) { $skipped++; continue; }

                        $this->store_game('hockey', 'nhl', [
                            'id'         => $id,
                            'league'     => 'NHL',
                            'league_name'=> 'NHL',
                            'country'    => '',
                            'home_id'    => (string) self::pick_path($game, 'homeTeam.id', ''),
                            'home_name'  => (string) self::pick_path($game, 'homeTeam.commonName.default',
                                            self::pick_path($game, 'homeTeam.abbrev', '')),
                            'away_id'    => (string) self::pick_path($game, 'awayTeam.id', ''),
                            'away_name'  => (string) self::pick_path($game, 'awayTeam.commonName.default',
                                            self::pick_path($game, 'awayTeam.abbrev', '')),
                            'kickoff'    => gmdate('Y-m-d H:i:s', strtotime((string) self::pick_path($game, 'startTimeUTC', 'now'))),
                            'status'     => $done ? 'FT' : 'NS',
                            'finished'   => $done ? 1 : 0,
                            'home_score' => $done ? (int) $hs : null,
                            'away_score' => $done ? (int) $as : null,
                        ], null);
                        $stored++;
                    }
                }
            }
        } elseif ($key === 'mlb') {
            // A single call covers the whole range.
            $body = $this->mlb_schedule(
                wp_date('Y-m-d', time() - $days_back * DAY_IN_SECONDS),
                wp_date('Y-m-d', time() + 5 * DAY_IN_SECONDS)
            );
            if (is_wp_error($body)) {
                $this->mark($key, false, $body->get_error_message());
                $this->outcome($key, $body->get_error_message());
                return 0;
            }
            foreach ((array) self::pick_path($body, 'dates', []) as $day) {
                foreach ((array) self::pick_path($day, 'games', []) as $game) {
                    $id = (string) self::pick_path($game, 'gamePk', '');
                    if ($id === '') { $skipped++; continue; }
                    $state = strtolower((string) self::pick_path($game, 'status.abstractGameState', ''));
                    $hs = self::pick_path($game, 'teams.home.score');
                    $as = self::pick_path($game, 'teams.away.score');
                    $done = ($state === 'final') && is_numeric($hs) && is_numeric($as);
                    if ($done && $this->already_have('baseball', 'mlb', $id)) { $skipped++; continue; }

                    $this->store_game('baseball', 'mlb', [
                        'id'         => $id,
                        'league'     => 'MLB',
                        'league_name'=> 'MLB',
                        'country'    => '',
                        'home_id'    => (string) self::pick_path($game, 'teams.home.team.id', ''),
                        'home_name'  => (string) self::pick_path($game, 'teams.home.team.name', ''),
                        'away_id'    => (string) self::pick_path($game, 'teams.away.team.id', ''),
                        'away_name'  => (string) self::pick_path($game, 'teams.away.team.name', ''),
                        'kickoff'    => gmdate('Y-m-d H:i:s', strtotime((string) self::pick_path($game, 'gameDate', 'now'))),
                        'status'     => $done ? 'FT' : 'NS',
                        'finished'   => $done ? 1 : 0,
                        'home_score' => $done ? (int) $hs : null,
                        'away_score' => $done ? (int) $as : null,
                    ], null);
                    $stored++;
                }
            }
        }

        $summary = $stored . ' αγώνες αποθηκεύτηκαν, ' . $skipped . ' αγνοήθηκαν.';
        $this->mark($key, $stored > 0, $summary);
        $this->outcome($key, $summary);
        return $stored;
    }

    /* ---------------------------------------------------------------- espn */

    /**
     * ESPN's own endpoints — the ones its site and app use. No key, no
     * registration, and full box scores. Undocumented, so it could change, but
     * it has held steady for years and is the only free source that reliably
     * carries rebounds and assists for the American competitions.
     */
    public static function espn_leagues() {
        return [
            'basketball/nba'                       => ['NBA', 'nba'],
            'basketball/wnba'                      => ['WNBA', 'basketball'],
            'basketball/mens-college-basketball'   => ['NCAA ανδρών', 'basketball'],
            'basketball/womens-college-basketball' => ['NCAA γυναικών', 'basketball'],
        ];
    }

    /**
     * The rest of ESPN, which uses exactly the same routes.
     *
     * Tennis, hockey and baseball were carrying history and no fixtures, which
     * makes a sport dead weight — it fills the database and can never produce
     * a suggestion. ESPN publishes the schedule for all of them on the same
     * scoreboard endpoint the basketball reader already uses, so covering them
     * costs a line each rather than a new integration.
     */
    /**
     * ESPN's football is deliberately closed to us.
     *
     * The route is right and the league codes are right; the answer is 403 —
     * forbidden — on every one of them, while basketball and tennis reply
     * normally from the same server on the same minute. That is not a fault to
     * work around: they are treating football differently on purpose, and a
     * browser user-agent would only be a way of pretending not to have been
     * told. The rule here has always been that the restaurants must never be
     * put at risk by this module, and an IP block would do exactly that.
     *
     * Kept as a record so nobody spends another evening rediscovering it.
     */
    public static function espn_football_blocked() {
        return ['soccer/swe.1', 'soccer/nor.1', 'soccer/den.1', 'soccer/fin.1'];
    }

    public static function espn_other() {
        return [
            'tennis/atp'                => ['ATP', 'tennis'],
            'tennis/wta'                => ['WTA', 'tennis'],
            /* Challenger and ITF were tried and removed: ESPN answers
               /tennis/atp-challenger with {"code":400,"message":"Failed to
               get events endpoint."} — those tours are not leagues it
               publishes. The step retried, hit the same wall, and the scan
               stopped there. More tennis needs another provider, not another
               slug. */
            /* ESPN — NHL removed, and this is the one that was stopping the
               scan. There were two NHL steps: the league's own API and this
               one. I took out the first and the shop watched the second stop
               it again — 67 steps became 66 and the same message came back.
               Both are gone now. Its season starts in October. */
            /* Baseball removed at the shop's request.
             *
             * Two hundred and forty games a fortnight, each one a separate
             * request for statistics, and not a single suggestion came out of
             * it: seventy-four in the window, zero with history on both sides.
             * It was the step the scan stalled on, for no return at all.
             *
             * Left as a line rather than deleted so it is one edit to bring
             * back if it is ever wanted. */
            // 'baseball/mlb'           => ['MLB', 'baseball'],
            /* American football removed at the shop's request, alongside
             * baseball. One match in the window, no history, no suggestion —
             * and the same per-game statistics fetch that made the baseball
             * step stall. The season starts in September; if it is ever
             * wanted back it is two lines. */
            // 'football/nfl'           => ['NFL', 'american-football'],
            // 'football/college-football' => ['NCAA football', 'american-football'],
        ];
    }

    public static function espn_all() {
        /* 4.91.1: μόνο τα αθλήματα που επιτρέπει η κύρια κλάση (ποδόσφαιρο,
           μπάσκετ, NBA). Το τένις ATP/WTA (~3.300 αγώνες ανά σάρωση) δεν
           ζητείται πια από καμία διαδρομή. */
        $all = array_merge(self::espn_leagues(), self::espn_other());
        if (class_exists('EMenu_DP82') && method_exists('EMenu_DP82', 'allowed_sports')) {
            $ok = EMenu_DP82::allowed_sports();
            $all = array_filter($all, function ($meta) use ($ok) {
                return isset($meta[1]) && in_array((string) $meta[1], $ok, true);
            });
        }
        return $all;
    }

    /**
     * ESPN answered 400 to every request for weeks, and the cause was here:
     * the sport was hard-coded to basketball and the league was url-encoded,
     * so "tennis/atp" became "basketball/tennis%2Fatp" — a path that cannot
     * exist. The slash is part of the route, not a value to escape.
     */
    /**
     * A league that is out of season sleeps for twelve hours.
     *
     * In August the NBA, both college basketballs and college football return
     * nothing across the whole window — eighteen requests each, to be told
     * eighteen times that there is no game. That is four steps of pure waiting
     * in every scan, and it is where scans die.
     *
     * Deleting them would work until October and then have to be undone by
     * hand, which is a thing nobody remembers to do. So instead: a league
     * whose last run found nothing at all is left alone for twelve hours, and
     * tries again after. When its season starts it wakes up by itself.
     *
     * Twelve hours rather than days: a competition can begin overnight, and
     * half a day of not noticing is the most this should ever cost.
     */
    private function league_dormant($league) {
        return (bool) get_transient('emenu_dp82_sleep_' . md5($league));
    }

    private function league_sleeps($league, $found, $empty_days) {
        if ($found > 0) {
            delete_transient('emenu_dp82_sleep_' . md5($league));
            return;
        }
        /* Only when every day came back empty. A league that answered with
           errors is a different problem and should keep being asked. */
        if ($empty_days >= 5) {
            set_transient('emenu_dp82_sleep_' . md5($league), 1, 12 * HOUR_IN_SECONDS);
        }
    }

    public function espn_scoreboard($league, $date) {
        $path = strpos($league, '/') === false ? 'basketball/' . $league : $league;

        /* A name the endpoint will answer to.
         *
         * NHL and MLB both refuse WordPress's own user agent outright, and the
         * comment beside those two says so — ESPN was left sending nothing at
         * all, and the tennis reader has been refused twice a scan since. The
         * header costs nothing and the two neighbours already proved it is
         * what these endpoints want. */
        $headers = [
            'User-Agent' => 'Mozilla/5.0 (compatible; DP82/1.0)',
            'Accept'     => 'application/json',
        ];

        $url = add_query_arg(
            ['dates' => wp_date('Ymd', strtotime($date)), 'limit' => 100],
            'https://site.api.espn.com/apis/site/v2/sports/' . $path . '/scoreboard'
        );
        $body = $this->get($url, $headers, 2 * HOUR_IN_SECONDS);
        if (!is_wp_error($body)) return $body;

        // Some sports refuse the extra parameters; ask plainly before giving up.
        $body = $this->get(add_query_arg(['dates' => wp_date('Ymd', strtotime($date))],
            'https://site.api.espn.com/apis/site/v2/sports/' . $path . '/scoreboard'),
            $headers, 2 * HOUR_IN_SECONDS);
        if (!is_wp_error($body)) return $body;

        $this->note('ESPN ' . $path . ': απέτυχε — ' . $body->get_error_message() . ' — ' . $url);
        return $body;
    }

    public function espn_summary($league, $event) {
        $path = strpos($league, '/') === false ? 'basketball/' . $league : $league;
        $url = add_query_arg(
            ['event' => $event],
            'https://site.web.api.espn.com/apis/site/v2/sports/' . $path . '/summary'
        );
        return $this->get($url, [
            'User-Agent' => 'Mozilla/5.0 (compatible; DP82/1.0)',
            'Accept'     => 'application/json',
        ], DAY_IN_SECONDS);
    }

    /** Team totals out of an ESPN summary: statistics carry name and value. */
    public function espn_totals($summary) {
        if (!is_array($summary) || empty($summary['boxscore']['teams'])) return null;
        $wanted = [
            'rebounds'  => ['totalRebounds', 'rebounds'],
            'assists'   => ['assists'],
            'steals'    => ['steals'],
            'blocks'    => ['blocks'],
            'turnovers' => ['turnovers', 'totalTurnovers'],
            'fouls'     => ['fouls', 'personalFouls'],
            'points'    => ['points'],
        ];

        $out = [];
        foreach (array_values($summary['boxscore']['teams']) as $index => $team) {
            if (empty($team['statistics'])) continue;
            $flat = [];
            foreach ($team['statistics'] as $stat) {
                if (!isset($stat['name'])) continue;
                $value = isset($stat['displayValue']) ? $stat['displayValue'] : null;
                if (is_numeric($value)) $flat[$stat['name']] = (float) $value;
            }
            if (!$flat) continue;
            $row = [];
            foreach ($wanted as $metric => $names) {
                $row[$metric] = null;
                foreach ($names as $name) {
                    if (isset($flat[$name])) { $row[$metric] = $flat[$name]; break; }
                }
            }
            $out[$index === 0 ? 'home' : 'away'] = $row;
        }
        return $out ? $out : null;
    }

    /* ---------------------------------------------------------- euroleague */

    public function el_games($competition) {
        $season = $this->season_code($competition);
        $url = 'https://api-live.euroleague.net/v2/competitions/' . rawurlencode($competition)
             . '/seasons/' . rawurlencode($season) . '/games';
        $body = $this->get($url, [], 3 * HOUR_IN_SECONDS);
        if (is_wp_error($body)) return $body;
        $games = self::unwrap($body);
        return is_array($games) ? $games : [];
    }

    /**
     * Their older box-score route answers XML whatever you ask for, which is
     * what "the response was not JSON" meant. The versioned routes are tried
     * first and the legacy one kept as a last resort.
     */
    public function el_boxscore($competition, $gamecode) {
        $season = $this->season_code($competition);
        $candidates = [
            'https://api-live.euroleague.net/v3/competitions/' . rawurlencode($competition)
                . '/seasons/' . rawurlencode($season) . '/games/' . rawurlencode($gamecode) . '/stats',
            'https://api-live.euroleague.net/v2/competitions/' . rawurlencode($competition)
                . '/seasons/' . rawurlencode($season) . '/games/' . rawurlencode($gamecode) . '/stats',
            add_query_arg(['gamecode' => $gamecode, 'seasoncode' => $season],
                'https://live.euroleague.net/api/Boxscore'),
        ];
        $last = null;
        foreach ($candidates as $url) {
            $body = $this->get($url, [], DAY_IN_SECONDS);
            if (!is_wp_error($body)) return $body;
            $last = $body;
        }
        return $last;
    }

    /**
     * Find the totals wherever they sit, rather than guessing the shape.
     *
     * Two releases were spent guessing at this structure and both were wrong.
     * This walks the response looking for the numbers themselves: an object
     * carrying both a rebound count and an assist count is a team's totals,
     * whatever the keys around it happen to be called this season.
     */
    private static function find_totals($node, $depth = 0) {
        if (!is_array($node) || $depth > 6) return [];

        $flat = [];
        foreach ($node as $k => $v) {
            if (!is_array($v)) $flat[strtolower((string) $k)] = $v;
        }
        $has = function ($keys) use ($flat) {
            foreach ($keys as $key) {
                if (isset($flat[$key]) && is_numeric($flat[$key])) return true;
            }
            return false;
        };
        if ($has(['totalrebounds', 'totreb', 'rebounds', 'reb'])
            && $has(['assistances', 'assists', 'ast'])) {
            return [$flat];
        }

        $found = [];
        foreach ($node as $child) {
            foreach (self::find_totals($child, $depth + 1) as $hit) {
                $found[] = $hit;
                if (count($found) >= 2) return $found;
            }
        }
        return $found;
    }

    public function el_totals($boxscore) {
        $sides = self::find_totals(self::unwrap($boxscore));
        if (count($sides) >= 2) {
            $out = [];
            foreach (array_slice($sides, 0, 2) as $index => $flat) {
                $out[$index === 0 ? 'home' : 'away'] = [
                    'rebounds'  => self::pick($flat, ['totalrebounds', 'totreb', 'rebounds', 'reb']),
                    'assists'   => self::pick($flat, ['assistances', 'assists', 'ast']),
                    'steals'    => self::pick($flat, ['steals', 'st']),
                    'blocks'    => self::pick($flat, ['blocksfavour', 'blocks', 'bs']),
                    'turnovers' => self::pick($flat, ['turnovers', 'to']),
                    'fouls'     => self::pick($flat, ['foulscommited', 'foulscommitted', 'fouls', 'pf']),
                    'points'    => self::pick($flat, ['points', 'pts', 'score']),
                ];
            }
            return $out;
        }
        return $this->el_totals_legacy($boxscore);
    }

    private function el_totals_legacy($boxscore) {
        $boxscore = self::unwrap($boxscore);
        if (!is_array($boxscore)) return null;

        // Try the shapes we know, then look for the numbers wherever they are.
        $deep = self::deep_totals($boxscore);
        if ($deep) return $deep;
        $teams = null;
        foreach (['Stats', 'stats', 'teams', 'teamStats'] as $field) {
            if (!empty($boxscore[$field]) && is_array($boxscore[$field])) { $teams = $boxscore[$field]; break; }
        }
        if (!$teams) return null;
        $out = [];
        foreach (array_values($teams) as $index => $team) {
            $totals = null;
            foreach (['totr', 'Totals', 'totals', 'total'] as $field) {
                if (!empty($team[$field]) && is_array($team[$field])) { $totals = $team[$field]; break; }
            }
            if (!is_array($totals)) continue;
            $out[$index === 0 ? 'home' : 'away'] = [
                'rebounds'  => self::pick($totals, ['TotalRebounds', 'totalRebounds', 'TotalReb', 'totalRebounds']),
                'assists'   => self::pick($totals, ['Assistances', 'Assists', 'AS']),
                'steals'    => self::pick($totals, ['Steals', 'ST']),
                'blocks'    => self::pick($totals, ['BlocksFavour', 'Blocks', 'BS']),
                'turnovers' => self::pick($totals, ['Turnovers', 'TO']),
                'fouls'     => self::pick($totals, ['FoulsCommited', 'FoulsCommitted', 'PF']),
                'points'    => self::pick($totals, ['Points', 'PTS']),
            ];
        }
        return $out ? $out : null;
    }

    /* ------------------------------------------------------------- ingest */

    private function table($which) {
        global $wpdb;
        return $wpdb->prefix . 'emenu_dp82_' . $which;
    }

    /**
     * Store one finished game and its team totals.
     *
     * Team ids are prefixed per source so two feeds can never be mistaken for
     * one another, exactly as football-data's are. The metrics land in the same
     * matchstats table the rest of the module already reads, so nothing
     * downstream needs to know where they came from.
     */
    /**
     * Ένα πεδίο που μπορεί να είναι κείμενο ή αντικείμενο.
     *
     * Το Big Balls επιστρέφει «home»: «Arsenal» σε ένα παράδειγμα και
     * αντικείμενο με «name» σε άλλο. Αντί να μαντέψω ποιο ισχύει, δέχομαι
     * και τα δύο: η μορφή μιας πηγής αλλάζει χωρίς προειδοποίηση, και ένας
     * αναγνώστης που σπάει σε αυτό είναι ένας πάροχος που σιωπά.
     */
    private static function loose($value, $keys = ['name', 'title', 'value']) {
        if (is_string($value) || is_numeric($value)) return (string) $value;

        if (is_array($value)) {
            foreach ($keys as $k) {
                if (isset($value[$k]) && (is_string($value[$k]) || is_numeric($value[$k]))) {
                    return (string) $value[$k];
                }
            }
        }

        return '';
    }

    /**
     * Οι αγώνες του Big Balls.
     *
     * Μία κλήση ανά άθλημα φέρνει όλη τη λίστα — δεν ζητιούνται στατιστικά
     * ανά αγώνα, που είναι ακριβώς αυτό που έκαιγε το όριο του Highlightly.
     * Το σκορ έρχεται μέσα στη λίστα και αρκεί για πρόταση συνόλου πόντων.
     */
    public function ingest_bigballs($sport = 'basketball') {
        $s = $this->settings();
        $key = trim((string) (isset($s['bb_key']) ? $s['bb_key'] : ''));

        if ($key === '') return 0;

        /* Ο μετρητής είναι ανά ΑΘΛΗΜΑ, όχι ανά αίτημα: η ingest_bigballs()
           καλείται δύο φορές (μπάσκετ, ποδόσφαιρο) και χωρίς μηδενισμό η
           δεύτερη αναφορά θα κουβαλούσε και τα δεμένα της πρώτης. */
        $this->tied_teams = 0;

        /* ΣΕΛΙΔΟΠΟΙΗΣΗ — με ΡΗΤΟ όριο σελίδας.
         *
         * Η 4.81.0 ζητούσε «&page=N» χωρίς όριο και έπαιρνε 50 αγώνες τη
         * φορά: οκτώ κλήσεις για 400 αγώνες. Η δημόσια τεκμηρίωση του
         * παρόχου (openapi.json, ανοιχτή χωρίς κλειδί) λέει δύο πράγματα:
         *
         *  - Οι λίστες σελιδοποιούνται με «limit» και «offset». Το «page=N»
         *    είναι ΜΟΝΟ συντόμευση για «offset=(N-1)*limit» υπολογισμένη
         *    πάνω στο ΠΡΟΕΠΙΛΕΓΜΕΝΟ όριο της διεύθυνσης — όχι σε αυτό που
         *    στέλνουμε εμείς. Γι' αυτό δεν στέλνονται ποτέ μαζί: «limit=200»
         *    με «page=2» θα ζητούσε από τη θέση 50 ενώ θα έφερνε 200, κι
         *    έτσι θα ξαναδιάβαζε τα ίδια και θα άφηνε τρύπες.
         *  - Το ανώτατο όριο σελίδας είναι 200.
         *
         * Άρα: 200 ανά κλήση, και το «offset» μετρημένο από τις εγγραφές που
         * ΟΝΤΩΣ ήρθαν, όχι από το όριο που ζητήσαμε. Έτσι το ίδιο αίτημα
         * είναι σωστό είτε τιμηθεί το όριο (200 ανά σελίδα, δύο κλήσεις για
         * 400 αγώνες) είτε αγνοηθεί (50 ανά σελίδα, όπως σήμερα) — χωρίς να
         * μαντεύει κανείς ποιο από τα δύο έγινε.
         *
         * Το ταβάνι των οκτώ κλήσεων μένει ακριβώς όπως ήταν. Στη χειρότερη
         * περίπτωση δηλαδή συμπεριφερόμαστε όπως σήμερα· στην αναμενόμενη,
         * παίρνουμε τους ίδιους αγώνες με δύο κλήσεις αντί για οκτώ.
         *
         * Και αν η ΠΡΩΤΗ σελίδα γυρίσει σφάλμα με το όριο πάνω της, ξαναπάμε
         * μία φορά με το ΑΚΡΙΒΕΣ αίτημα της 4.81.0 («&page=N», χωρίς όριο),
         * που είναι μετρημένο και δουλεύει. Μια παράμετρος που δεν άρεσε στον
         * πάροχο δεν επιτρέπεται να μας αφήσει με μηδέν αγώνες. */
        $rows      = [];
        $seen_ids  = [];
        $page_size = 0;
        $bb_pages  = 0;
        $bb_got    = 0;
        $bb_limit  = 200;
        $bb_again  = false;

        /* Οι μετρητές δηλώνονται ΕΔΩ, έξω από τον βρόχο, γιατί διαβάζονται πιο
           κάτω — δήλωση μέσα στο «do» τρέχει στην PHP αλλά είναι εύθραυστη και
           ο ελεγκτής τη χτυπάει, σωστά. Δεν χρειάζονται μηδένισμα στη δεύτερη
           προσπάθεια: η επανάληψη ξεκινά μόνο όταν αποτύχει η ΠΡΩΤΗ σελίδα,
           δηλαδή πριν μπει έστω μία εγγραφή σε αυτούς. */
        do {
            $bb_again = false;

            for ($page = 1; $page <= 8; $page++) {
                $url = 'https://api.bigballsdata.com/v1/matches?sport=' . rawurlencode($sport);
                if ($bb_limit > 0) {
                    $url .= '&limit=' . $bb_limit;
                    if ($page > 1) $url .= '&offset=' . $bb_got;
                } elseif ($page > 1) {
                    $url .= '&page=' . $page;
                }

                $res = wp_remote_get($url, ['timeout' => 25, 'headers' => [
                    'Authorization' => 'Bearer ' . $key,
                    'Accept'        => 'application/json',
                ]]);

                if (is_wp_error($res)) {
                    if ($page === 1) {
                        /* Μία επανάληψη χωρίς το όριο, πριν τα παρατήσουμε. */
                        if ($bb_limit > 0) {
                            $bb_limit = 0;
                            $bb_again = true;
                            break;
                        }
                        $this->mark('bigballs', false, $res->get_error_message());
                        return 0;
                    }
                    break;
                }

                $code = (int) wp_remote_retrieve_response_code($res);
                $body = json_decode(wp_remote_retrieve_body($res), true);

                if ($code !== 200 || !is_array($body)) {
                    if ($page === 1) {
                        if ($bb_limit > 0) {
                            $bb_limit = 0;
                            $bb_again = true;
                            break;
                        }
                        $this->mark('bigballs', false, 'HTTP ' . $code);
                        return 0;
                    }
                    break;
                }

                $batch = isset($body['data']) && is_array($body['data']) ? $body['data'] : $body;
                if (!is_array($batch) || !$batch) break;

                if ($page === 1) $page_size = count($batch);

                /* Ο δείκτης της επόμενης σελίδας: ό,τι ήρθε, όχι ό,τι ζητήθηκε. */
                $bb_got += count($batch);

                $fresh = 0;
                foreach ($batch as $one) {
                    $one_id = is_array($one) && isset($one['id']) ? (string) $one['id'] : '';
                    if ($one_id === '' || isset($seen_ids[$one_id])) continue;
                    $seen_ids[$one_id] = true;
                    $rows[] = $one;
                    $fresh++;
                }

                $bb_pages = $page;

                /* Τίποτα καινούριο: ή αγνοήθηκε η σελιδοποίηση, ή τελείωσε η λίστα. */
                if ($fresh === 0) break;
                /* Μισή σελίδα σημαίνει τελευταία σελίδα. */
                if ($page_size > 0 && count($batch) < $page_size) break;
                if ($this->step_deadline_passed()) break;
            }
        } while ($bb_again);

        $stored = 0;
        $timed  = 0;
        $soon   = 0;
        $sample = '';

        $window = time() + 48 * HOUR_IN_SECONDS;

        foreach ((array) $rows as $m) {
            if (!is_array($m)) continue;

            if ($sample === '' && isset($m['kickoff_utc'])) {
                $sample = substr((string) $m['kickoff_utc'], 0, 30);
            }

            $id = isset($m['id']) ? (string) $m['id'] : '';
            if ($id === '') continue;

            $home = self::loose(isset($m['home']) ? $m['home'] : '');
            $away = self::loose(isset($m['away']) ? $m['away'] : '');
            if ($home === '' || $away === '') continue;

            $kick = isset($m['kickoff_utc']) ? (string) $m['kickoff_utc'] : '';
            $when = $kick !== '' ? strtotime($kick) : 0;

            if ($when) {
                $timed++;
                if ($when >= time() && $when <= $window) $soon++;
            }

            $status = self::loose(isset($m['status']) ? $m['status'] : '');
            $done   = in_array(strtolower($status),
                        ['finished', 'ft', 'final', 'ended', 'complete'], true);

            /* Το σκορ μπορεί να είναι {home,away} ή {value:{home,away}}. */
            $hs = $as = null;
            $sc = isset($m['score']) ? $m['score'] : null;
            if (is_array($sc)) {
                $inner = isset($sc['value']) && is_array($sc['value']) ? $sc['value'] : $sc;
                if (isset($inner['home']) && is_numeric($inner['home'])) $hs = (int) $inner['home'];
                if (isset($inner['away']) && is_numeric($inner['away'])) $as = (int) $inner['away'];
            }

            $this->store_game($sport, 'bigballs', [
                'id'          => $id,
                'league'      => self::loose(isset($m['league']) ? $m['league'] : '', ['id', 'slug', 'name']),
                'league_name' => self::loose(isset($m['league']) ? $m['league'] : ''),
                'country'     => '',
                'home_id'     => $home,
                'home_name'   => $home,
                'away_id'     => $away,
                'away_name'   => $away,
                'kickoff'     => $when ? gmdate('Y-m-d H:i:s', $when) : '',
                'status'      => $status,
                'finished'    => $done ? 1 : 0,
                'home_score'  => $hs,
                'away_score'  => $as,
            ], null);

            $stored++;
        }

        /* Πόσοι έχουν ώρα και πόσοι είναι μπροστά μας.
           Αποθηκεύτηκαν πενήντα και στο 48ωρο δεν φάνηκε κανένας: ή η ώρα δεν
           διαβάστηκε, ή οι αγώνες είναι περασμένοι. Δύο αριθμοί το λένε,
           χωρίς να χρειάζεται να μαντέψει κανείς. */
        /* Η αναλυτική γραμμή πάει στο ΗΜΕΡΟΛΟΓΙΟ, με το άθλημα μπροστά.
           Η κατάσταση στον πίνακα κρατάει μία γραμμή ανά πηγή, οπότε με δύο
           περάσματα το ένα θα έσβηνε το άλλο — και οι αριθμοί που λένε αν
           διαβάστηκε σωστά η ώρα είναι ακριβώς αυτοί που χρειάζονται ανά
           άθλημα, όχι αθροισμένοι. */
        $this->note(sprintf(
            'Big Balls · %s: %d σελίδες × %d ανά σελίδα · %d αγώνες αποθηκεύτηκαν · '
          . '%d με ώρα · %d μέσα στο 48ωρο · %d ομάδες δέθηκαν με υπάρχον ιστορικό · '
          . 'δείγμα ώρας: %s',
            $sport, $bb_pages, $page_size, $stored, $timed, $soon, $this->tied_teams,
            $sample !== '' ? $sample : '—'));

        $this->mark('bigballs', true, sprintf(
            '%s: %d αγώνες αποθηκεύτηκαν · %d με ώρα · %d μέσα στο 48ωρο · δείγμα ώρας: %s',
            $sport, $stored, $timed, $soon, $sample !== '' ? $sample : '—'));

        return $stored;
    }

    /**
     * Οι αγώνες του BALLDONTLIE.
     *
     * Γράφτηκε από την τεκμηρίωσή τους και όχι από πραγματική απάντηση: τον
     * Σεπτέμβριο δεν παίζεται NBA, οπότε η δοκιμή επέστρεψε σωστά μηδέν
     * εγγραφές. Τα ονόματα πεδίων είναι αυτά που δημοσιεύουν —
     * home_team, visitor_team, home_team_score, visitor_team_score — και
     * διαβάζονται ανεκτικά, ώστε μια διαφορά στη μορφή να μη σταματήσει την
     * εισαγωγή σιωπηλά.
     *
     * Πέντε κλήσεις το λεπτό στο δωρεάν πακέτο: τρεις μέρες ανά σάρωση, όχι
     * περισσότερες.
     */
    public function ingest_balldontlie() {
        $s = $this->settings();
        $key = trim((string) (isset($s['bdl_key']) ? $s['bdl_key'] : ''));

        if ($key === '') return 0;

        $stored = 0;
        $seen   = 0;

        foreach ([0, 1, 2] as $offset) {
            $date = wp_date('Y-m-d', time() + $offset * DAY_IN_SECONDS);

            $res = wp_remote_get(
                'https://api.balldontlie.io/nba/v1/games?per_page=100&dates[]=' . rawurlencode($date),
                ['timeout' => 25, 'headers' => [
                    /* Το κλειδί ΣΚΕΤΟ, χωρίς «Bearer» — έτσι το θέλει αυτός ο
                       πάροχος, σε αντίθεση με το Big Balls δίπλα. */
                    'Authorization' => $key,
                    'Accept'        => 'application/json',
                ]]);

            if (is_wp_error($res)) {
                $this->mark('balldontlie', false, $res->get_error_message());
                return $stored;
            }

            $code = (int) wp_remote_retrieve_response_code($res);
            $body = json_decode(wp_remote_retrieve_body($res), true);

            if ($code !== 200 || !is_array($body)) {
                $this->mark('balldontlie', false, 'HTTP ' . $code);
                return $stored;
            }

            $rows = isset($body['data']) && is_array($body['data']) ? $body['data'] : [];

            foreach ($rows as $g) {
                if (!is_array($g)) continue;
                $seen++;

                $id = isset($g['id']) ? (string) $g['id'] : '';
                if ($id === '') continue;

                $home = self::loose(isset($g['home_team']) ? $g['home_team'] : '',
                                    ['full_name', 'name', 'abbreviation']);
                $away = self::loose(isset($g['visitor_team']) ? $g['visitor_team'] : '',
                                    ['full_name', 'name', 'abbreviation']);

                if ($home === '' || $away === '') continue;

                $when = isset($g['date']) ? strtotime((string) $g['date']) : 0;

                $status = self::loose(isset($g['status']) ? $g['status'] : '');
                $done   = in_array(strtolower($status), ['final', 'finished', 'ft'], true);

                $hs = isset($g['home_team_score']) && is_numeric($g['home_team_score'])
                    ? (int) $g['home_team_score'] : null;
                $as = isset($g['visitor_team_score']) && is_numeric($g['visitor_team_score'])
                    ? (int) $g['visitor_team_score'] : null;

                $this->store_game('nba', 'balldontlie', [
                    'id'          => $id,
                    'league'      => 'nba',
                    'league_name' => 'NBA',
                    'country'     => 'USA',
                    'home_id'     => $home,
                    'home_name'   => $home,
                    'away_id'     => $away,
                    'away_name'   => $away,
                    'kickoff'     => $when ? gmdate('Y-m-d H:i:s', $when) : '',
                    'status'      => $status,
                    'finished'    => $done ? 1 : 0,
                    'home_score'  => $hs,
                    'away_score'  => $as,
                ], null);

                $stored++;
            }
        }

        $this->mark('balldontlie', true,
            sprintf('%d αγώνες αποθηκεύτηκαν από %d γραμμές.', $stored, $seen));

        return $stored;
    }

    /**
     * Αυστηρό κλειδί ονόματος ομάδας — για ΤΑΥΤΟΤΗΤΑ, όχι για ομοιότητα.
     *
     * Υπάρχει ήδη name_key() στην κύρια κλάση και ΔΕΝ χρησιμοποιείται εδώ
     * επίτηδες: εκείνη πετάει λέξεις όπως «united» και «city», οπότε η
     * «Manchester United» και η «Manchester City» καταλήγουν και οι δύο
     * «manchester». Για ταίριασμα απόδοσης, με έλεγχο ώρας από πάνω, αυτό
     * είναι ανεκτό. Για το ΠΟΙΑ ΟΜΑΔΑ ΕΙΝΑΙ, θα ένωνε δύο διαφορετικούς
     * συλλόγους και θα έγραφε το ιστορικό του ενός στον άλλο — βλάβη που
     * δεν φαίνεται και δεν ξεγίνεται.
     *
     * Εδώ πέφτουν μόνο τόνοι, πεζά, σημεία στίξης και διπλά κενά. Τίποτα
     * δεν αφαιρείται από το όνομα. Αστοχία σημαίνει «μένουμε όπως σήμερα»·
     * λάθος ταίριασμα σημαίνει «χαλασμένο ιστορικό». Προτιμάμε την αστοχία.
     */
    private static function strict_key($name) {
        $name = mb_strtolower(trim((string) $name), 'UTF-8');
        $name = strtr($name, [
            'á'=>'a','à'=>'a','â'=>'a','ä'=>'a','ã'=>'a','å'=>'a','ā'=>'a',
            'é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','ē'=>'e',
            'í'=>'i','ì'=>'i','î'=>'i','ï'=>'i','ī'=>'i',
            'ó'=>'o','ò'=>'o','ô'=>'o','ö'=>'o','õ'=>'o','ø'=>'o','ō'=>'o',
            'ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u','ū'=>'u',
            'ç'=>'c','ñ'=>'n','š'=>'s','ž'=>'z','č'=>'c','ć'=>'c','ş'=>'s','ğ'=>'g',
        ]);
        $name = preg_replace('/[^a-z0-9 ]/', ' ', $name);
        $name = preg_replace('/\s+/', ' ', $name);
        return trim((string) $name);
    }

    /**
     * Το id που έχει ΗΔΗ η ομάδα σε άλλη πηγή, αν υπάρχει με βεβαιότητα.
     *
     * Το Big Balls έφερε 388 μελλοντικούς ποδοσφαιρικούς αγώνες και κανένας
     * δεν μπορούσε να μοντελοποιηθεί: οι ομάδες του αποθηκεύονταν ως
     * «bigballs:<όνομα>» και ήταν, για τη βάση, καινούριες ομάδες χωρίς
     * παρελθόν. Δίπλα τους το football-data κρατούσε ολόκληρες σεζόν για τις
     * ΙΔΙΕΣ ομάδες, κάτω από άλλο id.
     *
     * Ο χάρτης χτίζεται μία φορά ανά άθλημα και ανά αίτημα. Ένα όνομα που
     * οδηγεί σε δύο διαφορετικά id θεωρείται ΑΜΦΙΒΟΛΟ και πετιέται έξω —
     * δεν διαλέγουμε τυχαία ανάμεσα σε δύο ομάδες.
     */
    private function known_team_id($sport, $name, $skip_source = 'bigballs') {
        static $maps = [];

        $key = self::strict_key($name);
        if ($key === '') return '';

        /* Ο χάρτης αποκλείει ΤΗΝ ΠΗΓΗ ΠΟΥ ΔΕΝΕΤΑΙ, όχι πάντα το bigballs:
           αλλιώς η EuroLeague θα έβρισκε τον εαυτό της και το δέσιμο θα ήταν
           χωρίς νόημα. Ένας χάρτης ανά άθλημα ΚΑΙ ανά εξαιρούμενη πηγή. */
        $mkey = $sport . '|' . $skip_source;

        if (!isset($maps[$mkey])) {
            global $wpdb;
            $fx = $this->table('fixtures');

            $rows = (array) $wpdb->get_results($wpdb->prepare(
                "SELECT home_id AS tid, home_name AS tname FROM $fx
                  WHERE sport = %s AND provider <> %s AND home_name <> ''
                  UNION
                 SELECT away_id AS tid, away_name AS tname FROM $fx
                  WHERE sport = %s AND provider <> %s AND away_name <> ''",
                $sport, $skip_source, $sport, $skip_source));

            $map = [];
            foreach ($rows as $r) {
                $k = self::strict_key($r->tname);
                $v = (string) $r->tid;
                if ($k === '' || $v === '') continue;
                if (!isset($map[$k])) { $map[$k] = $v; continue; }
                /* Δεύτερο, διαφορετικό id για το ίδιο όνομα: αμφίβολο. */
                if ($map[$k] !== $v) $map[$k] = false;
            }
            $maps[$mkey] = $map;
        }

        if (!isset($maps[$mkey][$key])) return '';
        return $maps[$mkey][$key] === false ? '' : (string) $maps[$mkey][$key];
    }

    /**
     * Το id που θα γραφτεί για μια ομάδα αυτής της εγγραφής.
     *
     * ΜΟΝΟ για το Big Balls, και επίτηδες: είναι η πηγή που φέρνει αγώνες
     * πρωταθλημάτων τα οποία ήδη καλύπτονται αλλού, με δικά της ονόματα. Οι
     * υπόλοιπες πηγές μένουν ακριβώς όπως ήταν — καμία αλλαγή, κανένας
     * κίνδυνος για ό,τι ήδη δουλεύει.
     *
     * Αν δεν βρεθεί βέβαιη αντιστοιχία, επιστρέφεται το κανονικό id της
     * πηγής και τα πράγματα μένουν όπως σήμερα.
     */
    private function tie_team($sport, $source, $name, $fallback) {
        /* ΠΟΙΕΣ πηγές δένονται, και γιατί ΑΥΤΕΣ.
         *
         * Το bigballs μπήκε πρώτο γιατί έφερνε αγώνες πρωταθλημάτων που ήδη
         * καλύπτονται αλλού, με δικά του ονόματα.
         *
         * Η EuroLeague και το EuroCup μπαίνουν τώρα για άλλον λόγο, πιο
         * σοβαρό: είναι οι πηγές που γράφουν ΑΝΑΛΥΤΙΚΑ — ριμπάουντ, ασίστ —
         * στον πίνακα των στατιστικών. Η metric_history() τα ψάχνει με το id
         * της ομάδας του αγώνα:
         *
         *     WHERE ms.metric = %s AND f.home_id = %s AND ms.side = 'home'
         *
         * Οι επερχόμενοι αγώνες Euroleague όμως έρχονται από το apisports, με
         * δικά του αριθμητικά id. Άρα τα box score κάθονταν κάτω από άλλη
         * ταυτότητα και δεν τα έβρισκε ποτέ κανείς: ούτε μία πρόταση
         * ριμπάουντ ή ασίστ δεν έχει γίνει ποτέ, παρότι το μοντέλο τις ξέρει
         * και τις γραμμές τους τις έχει ορισμένες.
         *
         * Το ESPN ΔΕΝ μπαίνει, επίτηδες: καλύπτει και τένις, όπου «ομάδα»
         * είναι παίκτης, και δύο συνώνυμοι παίκτες θα ένωναν ιστορικά. Μπαίνει
         * μόνο αν χρειαστεί και αφού μετρηθεί χωριστά. */
        $ties = ['bigballs', 'euroleague', 'eurocup'];
        if (!in_array((string) $source, $ties, true)) return $fallback;

        $known = $this->known_team_id($sport, $name, (string) $source);
        if ($known === '') return $fallback;

        $this->tied_teams++;
        return $known;
    }

    /** Πόσες ομάδες δέθηκαν με υπάρχον ιστορικό σε αυτό το αίτημα. */
    private $tied_teams = 0;

    private function store_game($sport, $source, $game, $totals) {
        global $wpdb;
        $fixtures = $this->table('fixtures');
        $matchstats = $this->table('matchstats');
        $now = current_time('mysql', true);

        $row = [
            'sport'       => $sport,
            'provider'    => $source,
            'provider_id' => (string) $game['id'],
            'league_id'   => (string) $game['league'],
            'league_name' => (string) $game['league_name'],
            'country'     => (string) (isset($game['country']) ? $game['country'] : ''),
            'home_id'     => $this->tie_team($sport, $source,
                                 $game['home_name'], $source . ':' . $game['home_id']),
            'home_name'   => (string) $game['home_name'],
            'away_id'     => $this->tie_team($sport, $source,
                                 $game['away_name'], $source . ':' . $game['away_id']),
            'away_name'   => (string) $game['away_name'],
            'kickoff'     => $game['kickoff'],
            'status'      => (string) $game['status'],
            'finished'    => empty($game['finished']) ? 0 : 1,
            'home_score'  => isset($game['home_score']) ? (int) $game['home_score'] : null,
            'away_score'  => isset($game['away_score']) ? (int) $game['away_score'] : null,
            'updated_at'  => $now,
        ];

        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $fixtures WHERE provider = %s AND provider_id = %s AND sport = %s",
            $source, $row['provider_id'], $sport));
        if ($existing) {
            $wpdb->update($fixtures, $row, ['id' => (int) $existing]);
            $fixture_id = (int) $existing;
        } else {
            $wpdb->insert($fixtures, $row);
            $fixture_id = (int) $wpdb->insert_id;
        }
        if (!$fixture_id || !$totals) return $fixture_id;

        foreach ($totals as $side => $metrics) {
            foreach ($metrics as $metric => $value) {
                if ($value === null) continue;
                $wpdb->replace($matchstats, [
                    'fixture_id' => $fixture_id,
                    'sport'      => $sport,
                    'side'       => $side,
                    'metric'     => $metric,
                    'value'      => (float) $value,
                ]);
            }
        }
        $wpdb->update($fixtures, ['enriched' => 1], ['id' => $fixture_id]);
        return $fixture_id;
    }

    private function already_have($sport, $source, $provider_id) {
        global $wpdb;
        $fixtures = $this->table('fixtures');
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $fixtures WHERE sport = %s AND provider = %s AND provider_id = %s AND enriched = 1",
            $sport, $source, $provider_id));
    }

    /**
     * Pull recent finished games from one source, box scores included.
     *
     * Runs as part of the ordinary scan; nothing has to be switched on or
     * tested by hand first. A source that errors is marked and skipped for the
     * day rather than retried into the ground, and marks itself working again
     * the moment it answers.
     */
    /**
     * Εξήντα αγώνες ανά πηγή, όχι δώδεκα.
     *
     * Το δώδεκα μπήκε όταν κάθε αγώνας κόστιζε μία κλήση για στατιστικά — και
     * τότε ήταν σωστό, γιατί δεκατρείς αγώνες σήμαιναν δεκατρείς κλήσεις και
     * ένα βήμα που δεν τελείωνε. Τώρα οι κλήσεις στατιστικών έχουν δικό τους
     * όριο, οπότε το πλαφόν περιόριζε μόνο πόσοι αγώνες ΓΡΑΦΟΝΤΑΙ στη βάση:
     * μία λίστα, μία κλήση, και δώδεκα από τους πενήντα κρατιούνταν.
     *
     * Φαινόταν στο διαγνωστικό ως «12 αγώνες» σε τρεις διαφορετικές πηγές,
     * με το ίδιο ακριβώς νούμερο — που δεν ήταν σύμπτωση αλλά το πλαφόν.
     */
    /**
     * Δεκατέσσερις μέρες πίσω, όχι τρεις.
     *
     * Το μοντέλο ζητάει «τέσσερις στους τελευταίους έξι» αγώνες ανά ομάδα.
     * Με τρεις μέρες παρελθόντος, καμία ομάδα μπάσκετ δεν έφτανε ποτέ τους
     * έξι: το ημερολόγιο έγραφε «0 ομάδες ιστορικού, 30 φόρμας» — δηλαδή
     * χτιζόταν, αλλά μοιρασμένο σε δεκάδες ομάδες που καμία δεν συμπλήρωνε
     * τον απαιτούμενο αριθμό.
     *
     * Το ποδόσφαιρο δεν το πάθαινε γιατί παίρνει ολόκληρες σεζόν δωρεάν από
     * τα CSV του football-data.co.uk — «3027 φόρμας» έναντι «30».
     *
     * Η λίστα κάθε ημέρας κοστίζει μία κλήση, οπότε δεκατέσσερις μέρες είναι
     * δεκατέσσερις κλήσεις: μέσα στα όρια και των τριών παρόχων, και μία
     * φορά· από τη δεύτερη σάρωση οι ήδη αποθηκευμένοι παραλείπονται.
     */
    public function ingest_source($key, $days = 7, $max_games = 60) {
        if (!$this->enabled($key)) return 0;

        $stored = 0;
        $errors = 0;

        // "espn" on its own means every league, which is 180 requests and
        // more than one step can finish. The queue now asks for one league at
        // a time as "espn:basketball/nba", and the whole set only when
        // something calls for it directly.
        if (strpos($key, 'espn:') === 0) {
            $only = substr($key, 5);
            $all = self::espn_all();
            if (!isset($all[$only])) return 0;
            return $this->ingest_espn_league($only, $all[$only][0], $all[$only][1]);
        }

        if ($key === 'espn') {
            // A share each, so the basketball leagues cannot consume the
            // whole budget before tennis, hockey or baseball are reached.
            $per_league = 40;   // enough for a fortnight of a running league
            $skipped = 0;   // every discarded row is counted, never silent
            foreach (self::espn_all() as $league => $meta) {
                list($label, $sport) = $meta;

                // A league found to be out of season sleeps; see league_sleeps().
                if ($this->league_dormant($league)) continue;
                // Six minutes of requests killed the step before it could
                // report anything. Three days back, three forward, and a
                // league that refuses twice in a row is left alone.
                $refusals = 0;
                $for_this = 0;
                $empty_days = 0;
                $before = $stored;
                // Backwards for box scores, forwards for something to predict
                // on. Only asking for finished games is why this source had
                // history and no fixtures.
                $offsets = [];
                for ($back = 1; $back <= $days; $back++) $offsets[] = -$back;
                for ($ahead = 0; $ahead <= 7; $ahead++) $offsets[] = $ahead;

                foreach ($offsets as $offset) {
                    if ($for_this >= $per_league) break;
                    $day = wp_date('Y-m-d', time() + $offset * DAY_IN_SECONDS);
                    if ($refusals >= 2) break;
                    if ($this->step_deadline_passed()) break;
                    $board = $this->espn_scoreboard($league, $day);
                    if (is_wp_error($board)) {
                        $refusals++;
                        $errors++;
                        $this->note(sprintf('ESPN %s · %s: %s', $league, $day, $board->get_error_message()));
                        $skipped++; continue;
                    }
                    $event_count = isset($board['events']) ? count((array) $board['events']) : 0;
                    if ($event_count === 0) { $empty_days++; }
                    $events = isset($board['events']) ? (array) $board['events'] : [];
                    foreach ($events as $event) {
                        if ($for_this >= $per_league) break;

                        // A team sport puts one match inside an event. Tennis
                        // puts a whole tournament there, with every match of
                        // the day as a separate competition — reading only the
                        // first is why tennis came back empty.
                        $competitions = self::pick_path($event, 'competitions', []);
                        if (!is_array($competitions) || !$competitions) { $skipped++; continue; }

                        foreach ($competitions as $index => $competition) {
                        if ($for_this >= $per_league) break;
                        $id = (string) (isset($competition['id']) ? $competition['id']
                              : (isset($event['id']) ? $event['id'] . '-' . $index : ''));
                        if ($id === '') { $skipped++; continue; }
                        $done = (bool) (self::pick_path($competition, 'status.type.completed')
                              ?: self::pick_path($event, 'status.type.completed'));
                        if ($done && $this->already_have($sport, 'espn', $id)) { $skipped++; continue; }

                        $competitors = isset($competition['competitors']) ? $competition['competitors'] : [];
                        if (count((array) $competitors) < 2) { $skipped++; continue; }
                        $home = $away = null;
                        foreach ($competitors as $c) {
                            if (isset($c['homeAway']) && $c['homeAway'] === 'home') $home = $c;
                            elseif (isset($c['homeAway'])) $away = $c;
                        }
                        // Tennis marks neither side as home, so fall back to
                        // the order they arrive in rather than discarding them.
                        if (!$home || !$away) {
                            $listed = array_values((array) $competitors);
                            if (count($listed) >= 2) { $home = $listed[0]; $away = $listed[1]; }
                        }
                        if (!$home || !$away) { $skipped++; continue; }

                        // A box score only exists once the game has been played.
                        $totals = null;
                        if ($done) {
                            $summary = $this->espn_summary($league, $id);
                            $totals = is_wp_error($summary) ? null : $this->espn_totals($summary);
                        }

                        // Football already arrives from three sources, so a
                        // fixture stored here is only useful if the model can
                        // tie it to the history it already holds — which the
                        // club-name matcher does, since ESPN writes "Malmo FF"
                        // where football-data writes "Malmo".
                        $this->store_game($sport, 'espn', [
                            'id'         => $id,
                            'league'     => $league,
                            'league_name'=> $label,
                            'country'    => '',
                            // Team sports carry a "team"; tennis carries an
                            // "athlete". Reading only the first is why every
                            // ATP and WTA match was fetched and then dropped.
                            /* An identifier that is never empty.
                             *
                             * ESPN gives tennis an athlete rather than a team,
                             * and the athlete's id does not arrive at the path
                             * this reads — the display name does, the id does
                             * not. Every player was therefore stored as
                             * "espn:" with nothing after it: one identifier
                             * shared by all of them.
                             *
                             * That is worse than having none. A lookup for a
                             * player's past matches compared one empty string
                             * against another and matched all eleven hundred,
                             * so the history check passed on evidence that
                             * belonged to strangers, while a check that needs
                             * a real count found nothing it could use.
                             *
                             * The name is the fallback, folded to a stable
                             * key. Two players with the same name would share
                             * a record, which is a small and rare error; every
                             * player sharing one record is a large and
                             * constant one. */
                            'home_id'    => self::competitor_key($home),
                            'home_name'  => self::pick_path($home, 'team.displayName',
                                            self::pick_path($home, 'athlete.displayName',
                                            self::pick_path($home, 'athlete.shortName', ''))),
                            'away_id'    => self::competitor_key($away),
                            'away_name'  => self::pick_path($away, 'team.displayName',
                                            self::pick_path($away, 'athlete.displayName',
                                            self::pick_path($away, 'athlete.shortName', ''))),
                            'kickoff'    => gmdate('Y-m-d H:i:s', strtotime((string) (
                                isset($competition['date']) ? $competition['date']
                                : (strpos($league, 'tennis/') === 0 ? $day . 'T12:00Z' : $event['date'])))),
                            'status'     => $done ? 'FT' : 'NS',
                            'finished'   => $done ? 1 : 0,
                            'home_score' => $done ? self::espn_score($home) : null,
                            'away_score' => $done ? self::espn_score($away) : null,
                        ], $totals);
                        $stored++;
                        $for_this++;
                        }
                    }
                }
                $this->note(sprintf('ESPN %s: %d αποθηκεύτηκαν, %d μέρες χωρίς αγώνες.',
                    $league, $stored - $before, $empty_days));
                    $this->league_sleeps($league, $stored - $before, $empty_days);
            }
        } elseif ($key === 'tennis') {
            /* The scores already stored as nothing, filled in first.
             *
             * Runs before the CSV reader and only until it has nothing left to
             * do, then never again. It is here rather than in its own step
             * because it is temporary work: once the thousand old rows have
             * their sets, this is a query that returns nothing and costs
             * nothing. */
            $filled = $this->backfill_tennis_scores();
            if ($filled) {
                $this->note(sprintf('Τένις: συμπληρώθηκαν %d σκορ που είχαν μείνει κενά.', $filled));
            }

            // Returns straight away: the generic summary at the end of this
            // method was overwriting the tennis reader's own, which is why its
            // note arrived with the numbers missing.
            return $this->ingest_tennis(200);
        } elseif ($key === 'nhl') {
            return $this->ingest_league_api($key);
        } elseif ($key === 'balldontlie') {
            return $this->ingest_balldontlie();

        } elseif ($key === 'bigballs') {
            /* ΚΑΙ ποδόσφαιρο, όχι μόνο μπάσκετ.
             *
             * Η πηγή σερβίρει εννιά αθλήματα από ένα σχήμα και η
             * ingest_bigballs() είναι ήδη παραμετρική: το άθλημα πάει στο URL
             * και στο store_game(). Απλώς κανείς δεν της ζήτησε ποτέ
             * ποδόσφαιρο — έμενε καρφωμένο το 'basketball' εδώ, στη μία
             * γραμμή που αποφασίζει.
             *
             * Με το API-Sports σε αναστολή, το ποδόσφαιρο στηριζόταν στα CSV
             * του football-data.co.uk και σε δώδεκα διοργανώσεις του
             * football-data.org. Αυτή η πηγή δίνει 844 πρωταθλήματα με 1.000
             * αιτήματα την ημέρα — και η κλήση είναι ΜΙΑ ανά άθλημα, γιατί
             * φέρνει όλους τους αγώνες μαζί. Δύο κλήσεις συνολικά, δηλαδή.
             *
             * Τα δύο σύνολα αθροίζονται και η κατάσταση γράφεται στο τέλος
             * από εδώ: αλλιώς το δεύτερο πέρασμα θα έγραφε πάνω από το πρώτο
             * και ο πίνακας θα έδειχνε μόνο το ποδόσφαιρο, σαν να μην είχε
             * γίνει ποτέ το μπάσκετ. */
            $bb_hoops = (int) $this->ingest_bigballs('basketball');
            $bb_foot  = (int) $this->ingest_bigballs('football');

            $this->mark('bigballs', true, sprintf(
                '%d αγώνες συνολικά · %d μπάσκετ · %d ποδόσφαιρο.',
                $bb_hoops + $bb_foot, $bb_hoops, $bb_foot));

            return $bb_hoops + $bb_foot;

        } elseif ($key === 'highlightly') {
            /* ΠΡΟΘΕΣΜΙΑ, όχι μόνο πλήθος ημερών.
             *
             * Με δεκατέσσερις μέρες και όριο εικοσιπέντε δευτερολέπτων ανά
             * κλήση, ένα βήμα μπορούσε να τρέξει πάνω από πεντακόσια
             * δευτερόλεπτα. Το κλείδωμα της σάρωσης όμως λήγει στα ενενήντα:
             * το επόμενο αίτημα έβρισκε ξεκλείδωτο, ξεκινούσε δεύτερο βήμα,
             * και τα βήματα συσσωρεύονταν μέχρι η CPU να φτάσει στο 100%.
             *
             * Εξήντα δευτερόλεπτα: μέσα στο κλείδωμα με περιθώριο. Ό,τι δεν
             * προλάβει, το παίρνει η επόμενη σάρωση — οι ήδη αποθηκευμένοι
             * παραλείπονται ούτως ή άλλως. */
            $hl_deadline = microtime(true) + 60;
            /* Πόσες κλήσεις αναλυτικών στατιστικών επιτρέπονται σε αυτή τη
               σάρωση. Ο μετρητής είναι ΕΞΩ από τους δύο βρόχους: μέσα τους θα
               μηδενιζόταν σε κάθε μέρα ή κάθε αγώνα και το όριο δεν θα ίσχυε. */
            $stat_calls = 0;

            $offsets = [];
            for ($back = 1; $back <= $days; $back++) $offsets[] = -$back;
            for ($ahead = 0; $ahead <= 5; $ahead++) $offsets[] = $ahead;

            foreach ($offsets as $offset) {
                if ($stored >= $max_games) break;
                if (microtime(true) > $hl_deadline) break;
                $rows = $this->hl_matches(wp_date('Y-m-d', time() + $offset * DAY_IN_SECONDS));
                if (is_wp_error($rows)) { $errors++; $skipped++; continue; }
                foreach ((array) self::unwrap($rows) as $match) {
                    if ($stored >= $max_games) break;
                    $id = isset($match['id']) ? (string) $match['id'] : '';
                    if ($id === '') { $skipped++; continue; }

                    // Every position the score is known to sit in.
                    $hs = self::pick_path($match, 'homeTeam.score');
                    foreach (['state.score.current.home', 'scores.home', 'homeScore', 'score.home'] as $where) {
                        if (is_numeric($hs)) break;
                        $hs = self::pick_path($match, $where);
                    }
                    $as = self::pick_path($match, 'awayTeam.score');
                    foreach (['state.score.current.away', 'scores.away', 'awayScore', 'score.away'] as $where) {
                        if (is_numeric($as)) break;
                        $as = self::pick_path($match, $where);
                    }

                    // A match with two scores whose start time has passed is
                    // finished. Requiring the word "finished" as well left
                    // twelve games from yesterday marked unplayed for ever,
                    // because this feed describes their state some other way.
                    $when = strtotime((string) self::pick_path($match, 'date', 'now'));
                    $done = is_numeric($hs) && is_numeric($as) && $when && $when < time();

                    if ($done && $this->already_have('basketball', 'highlightly', $id)) { $skipped++; continue; }

                    /* Τα αναλυτικά στατιστικά κοστίζουν ΜΙΑ κλήση ΑΝΑ ΑΓΩΝΑ.
                     *
                     * Η λίστα της ημέρας είναι μία κλήση και φέρνει τα πάντα —
                     * ομάδες, ώρα, σκορ. Τα στατιστικά όμως ζητιούνται ένα-ένα,
                     * και με 340 πρωταθλήματα οι εκατό δωρεάν κλήσεις της
                     * ημέρας τελειώνουν στα πρώτα λεπτά. Μετά ο πάροχος
                     * σταματάει να απαντάει και δεν μπαίνει ΚΑΝΕΝΑΣ αγώνας —
                     * ούτε καν αυτοί που θα έρχονταν δωρεάν με τη λίστα.
                     *
                     * Δέκα ανά σάρωση: οι αγώνες αποθηκεύονται όλοι, τα
                     * στατιστικά μαζεύονται σταδιακά στις επόμενες σαρώσεις.
                     * Για πρόταση συνόλου πόντων αρκεί το σκορ, που το έχουμε
                     * ήδη από τη λίστα. */
                    $totals = null;
                    if ($done && $stat_calls < 10) {
                        $stat_calls++;
                        $stats = $this->hl_stats($id);
                        $totals = is_wp_error($stats) ? null : $this->hl_totals($stats);
                    }

                    $this->store_game('basketball', 'highlightly', [
                        'id'         => $id,
                        'league'     => (string) self::pick_path($match, 'league.id', ''),
                        'league_name'=> (string) self::pick_path($match, 'league.name', ''),
                        'country'    => (string) self::pick_path($match, 'country.name', ''),
                        'home_id'    => self::pick_path($match, 'homeTeam.id', ''),
                        'home_name'  => self::pick_path($match, 'homeTeam.name', ''),
                        'away_id'    => self::pick_path($match, 'awayTeam.id', ''),
                        'away_name'  => self::pick_path($match, 'awayTeam.name', ''),
                        'kickoff'    => gmdate('Y-m-d H:i:s', strtotime((string) self::pick_path($match, 'date', 'now'))),
                        'status'     => $done ? 'FT' : 'NS',
                        'finished'   => $done ? 1 : 0,
                        'home_score' => $done && is_numeric($hs) ? (int) $hs : null,
                        'away_score' => $done && is_numeric($as) ? (int) $as : null,
                    ], $totals);
                    $stored++;
                }
            }
        } elseif ($key === 'euroleague' || $key === 'eurocup') {
            $competition = $key === 'euroleague' ? 'E' : 'U';
            $games = $this->el_games($competition);
            if (is_wp_error($games)) { $errors++; $games = []; }
            $games = array_reverse((array) $games);
            foreach ($games as $game) {
                if ($stored >= $max_games) break;
                $code = null;
                foreach (['gameCode', 'code', 'gamecode'] as $field) {
                    if (isset($game[$field])) { $code = (string) $game[$field]; break; }
                }
                if ($code === null) { $skipped++; continue; }
                $played = !empty($game['played']) || isset($game['homeScore']);
                if ($played && $this->already_have('basketball', $key, $code)) { $skipped++; continue; }

                // Fixtures yet to be played are stored too. Keeping only
                // finished games gives a source with perfect history and
                // nothing to predict on — the same fault fdcouk and the two
                // other basketball feeds had.
                $totals = null;
                if ($played) {
                    $box = $this->el_boxscore($competition, $code);
                    $totals = is_wp_error($box) ? null : $this->el_totals($box);
                }

                $this->store_game('basketball', $key, [
                    'id'         => $code,
                    'league'     => $competition,
                    'league_name'=> $key === 'euroleague' ? 'EuroLeague' : 'EuroCup',
                    'country'    => 'Europe',
                    'home_id'    => self::pick_path($game, 'home.code', self::pick_path($game, 'homeTeamCode', $code . 'H')),
                    'home_name'  => self::pick_path($game, 'home.name', self::pick_path($game, 'homeTeam', '')),
                    'away_id'    => self::pick_path($game, 'away.code', self::pick_path($game, 'awayTeamCode', $code . 'A')),
                    'away_name'  => self::pick_path($game, 'away.name', self::pick_path($game, 'awayTeam', '')),
                    'kickoff'    => gmdate('Y-m-d H:i:s', strtotime((string) self::pick_path($game, 'date', 'now'))),
                    'status'     => $played ? 'FT' : 'NS',
                    'finished'   => $played ? 1 : 0,
                    'home_score' => self::pick_path($game, 'homeScore'),
                    'away_score' => self::pick_path($game, 'awayScore'),
                ], $totals);
                $stored++;
            }
        }

        $summary = $stored
            ? ($stored . ' αγώνες αποθηκεύτηκαν, ' . $skipped . ' γραμμές αγνοήθηκαν.')
            : ('κανένας νέος αγώνας· ' . $skipped . ' γραμμές αγνοήθηκαν, ' . $errors . ' σφάλματα δικτύου.');
        $this->mark($key, $stored > 0 || $errors === 0, $summary);
        $this->outcome($key, $summary);
        return $stored;
    }

    /* -------------------------------------------------------------- tennis */

    /**
     * ATP matches as CSV, refreshed daily.
     *
     * Tennis earns its place by the calendar: it is played every week of the
     * year, including the weeks in August when the European leagues are
     * asleep. The scoreline gives games per set, so the total-games market
     * falls out of it directly — the same shape as an over/under on goals.
     *
     * Restored after being dropped: a clean rewrite of this file took it with
     * it, which is why the audit above now covers every source rather than
     * whichever one is being discussed.
     */
    public function tennis_files() {
        $body = $this->get('https://stats.tennismylife.org/api/data-files', [], 6 * HOUR_IN_SECONDS);
        if (is_wp_error($body)) return $body;
        $files = self::unwrap($body);
        return is_array($files) ? $files : [];
    }

    /** "6-4 7-6(5)" -> 13 games for the winner, 10 for the loser. */
    public static function tennis_games($score) {
        $score = trim((string) $score);
        if ($score === '') return null;
        $w = $l = 0;
        foreach (preg_split('/\s+/', $score) as $set) {
            $set = preg_replace('/\(\d+\)/', '', $set);
            if (!preg_match('/^(\d+)-(\d+)$/', $set, $m)) continue;
            $w += (int) $m[1];
            $l += (int) $m[2];
        }
        return ($w + $l) > 0 ? ['winner' => $w, 'loser' => $l] : null;
    }

    /**
     * ATP results from the TML database, as history for the tennis model.
     *
     * There was no ingest for this at all — only the helpers, written and then
     * never called, so the scan asked for tennis, found no branch, and
     * reported zero. It looked exactly like a source with nothing to give.
     *
     * A player is treated as a team and the scoreline is turned into games
     * won and lost, which makes total games behave like total goals and lets
     * the whole existing model apply unchanged.
     */
    public function ingest_tennis($max_rows = 400) {
        $files = $this->tennis_files();
        if (is_wp_error($files)) {
            $this->mark('tennis', false, $files->get_error_message());
            $this->note('Τένις: ο κατάλογος αρχείων απέτυχε — ' . $files->get_error_message());
            return 0;
        }

        // Newest file first; one is enough per scan.
        // The catalogue answers, but the earlier reader demanded a value
        // ending in ".csv" and found none — the names arrive in a field it did
        // not look at. Rather than insist on a shape, walk the whole response
        // and take any string that could be a file, then say what was actually
        // seen if none is.
        $strings = [];
        $walk = function ($node) use (&$walk, &$strings) {
            if (is_string($node)) { $strings[] = $node; return; }
            if (!is_array($node)) return;
            foreach ($node as $child) $walk($child);
        };
        $walk($files);

        $urls = [];
        foreach ($strings as $value) {
            $value = trim($value);
            if ($value === '' || strlen($value) > 300) continue;
            if (stripos($value, '.csv') === false && !preg_match('~^[\w./-]+$~', $value)) continue;
            if (strpos($value, 'http') === 0) { $urls[] = $value; continue; }
            $urls[] = 'https://stats.tennismylife.org/' . ltrim($value, '/');
        }
        $urls = array_values(array_unique($urls));

        if (!$urls) {
            $shape = wp_json_encode($files, JSON_UNESCAPED_UNICODE);
            $summary = 'ο κατάλογος δεν έδωσε ονόματα αρχείων· απάντησε: '
                     . mb_substr((string) $shape, 0, 300, 'UTF-8');
            $this->mark('tennis', false, $summary);
            $this->note('Τένις: ' . $summary);
            $this->outcome('tennis', $summary);
            return 0;
        }
        rsort($urls);
        $this->note(sprintf('Τένις: %d υποψήφια αρχεία, δοκιμάζεται %s', count($urls), basename($urls[0])));

        $this->note(sprintf('Τένις: %d αρχεία στον κατάλογο, δοκιμάζεται %s',
            count($urls), basename($urls[0])));

        // Bounded on purpose: this step killed the queue at exactly this line
        // for two releases. A short timeout and a size ceiling mean a slow or
        // enormous file costs the scan a few seconds, not the whole run.
        $res = wp_remote_get($urls[0], [
            'timeout'  => 12,
            'headers'  => ['Accept' => 'text/csv'],
            'limit_response_size' => 3 * MB_IN_BYTES,
        ]);
        $status = is_wp_error($res) ? $res->get_error_message() : wp_remote_retrieve_response_code($res);
        if (is_wp_error($res) || $status !== 200) {
            $this->mark('tennis', false, 'Το CSV δεν κατέβηκε: ' . $status);
            $this->note('Τένις: το CSV δεν κατέβηκε — ' . $status);
            return 0;
        }

        $body = str_replace(["\r\n", "\r"], "\n", wp_remote_retrieve_body($res));
        $lines = array_values(array_filter(explode("\n", $body), 'strlen'));
        // Only the most recent rows matter for form; the file holds years.
        if (count($lines) > 3000) $lines = array_slice($lines, 0, 1) + array_slice($lines, -3000);
        if (count($lines) < 2) {
            $this->note('Τένις: το αρχείο κατέβηκε αλλά ήταν άδειο.');
            return 0;
        }
        $head = str_getcsv(array_shift($lines));
        $this->note(sprintf('Τένις: %d γραμμές, στήλες: %s',
            count($lines), implode(', ', array_slice($head, 0, 8))));

        $stored = 0;
        $skipped = 0;
        foreach ($lines as $line) {
            if ($stored >= $max_rows) break;
            $cells = str_getcsv($line);
            if (count($cells) < 3) { $skipped++; continue; }
            $row = [];
            foreach ($head as $i => $key) {
                $key = trim((string) $key);
                if ($key !== '') $row[$key] = isset($cells[$i]) ? trim((string) $cells[$i]) : '';
            }

            $winner = isset($row['winner_name']) ? $row['winner_name'] : (isset($row['Winner']) ? $row['Winner'] : '');
            $loser  = isset($row['loser_name'])  ? $row['loser_name']  : (isset($row['Loser'])  ? $row['Loser']  : '');
            $score  = isset($row['score']) ? $row['score'] : (isset($row['Score']) ? $row['Score'] : '');
            if ($winner === '' || $loser === '') { $skipped++; continue; }

            $games = self::tennis_games($score);
            if (!$games) { $skipped++; continue; }

            $raw_date = isset($row['tourney_date']) ? $row['tourney_date'] : (isset($row['Date']) ? $row['Date'] : '');
            $ts = $raw_date !== '' ? strtotime(preg_match('/^\d{8}$/', $raw_date)
                ? substr($raw_date, 0, 4) . '-' . substr($raw_date, 4, 2) . '-' . substr($raw_date, 6, 2)
                : $raw_date) : false;
            if (!$ts) { $skipped++; continue; }

            $tourney = isset($row['tourney_name']) ? $row['tourney_name'] : 'ATP';
            $this->store_game('tennis', 'tml', [
                'id'         => md5($winner . '|' . $loser . '|' . $raw_date . '|' . $score),
                'league'     => 'ATP',
                'league_name'=> $tourney,
                'country'    => '',
                'home_id'    => sanitize_title($winner),
                'home_name'  => $winner,
                'away_id'    => sanitize_title($loser),
                'away_name'  => $loser,
                'kickoff'    => gmdate('Y-m-d H:i:s', $ts),
                'status'     => 'FT',
                'finished'   => 1,
                'home_score' => $games['winner'],
                'away_score' => $games['loser'],
            ], null);
            $stored++;
        }

        $summary = $stored . ' ματς αποθηκεύτηκαν, ' . $skipped . ' γραμμές αγνοήθηκαν από '
                 . basename($urls[0]);
        $this->mark('tennis', $stored > 0, $summary);
        $this->note('Τένις: ' . $summary);
        $this->outcome('tennis', $summary);
        return $stored;
    }

    /**
     * One ESPN league, as its own step.
     *
     * Asking for all ten in a single step meant roughly 180 requests, which no
     * step finishes: it died silently three scans running, recorded nothing,
     * and left the queue to be rescued by hand. Split this way each step makes
     * at most eighteen calls and reports for itself, so a league that breaks
     * costs that league only.
     */
    public function ingest_espn_league($league, $label, $sport) {
        /* The old rows repaired here, where the scan actually goes.
         *
         * The repair lived behind a step keyed 'tennis' that is not in the
         * queue — the scan runs espn:tennis/atp and espn:tennis/wta instead —
         * so it had never once executed. Eleven hundred matches waited for a
         * routine nothing called.
         *
         * Cheap after the first success: it asks for rows with no score, and
         * once there are none it marks itself done and returns immediately. */
        if ($sport === 'tennis') {
            $this->crumb($league . ' — συμπλήρωση σκορ');
            $filled = $this->backfill_tennis_scores();
            if ($filled) {
                $this->note(sprintf('Τένις: συμπληρώθηκαν %d σκορ που είχαν μείνει κενά.', $filled));
            }
        }

        $states = [];
        $stored = 0;
        $skipped = 0;
        $empty_days = 0;
        $refusals = 0;
        $tally = [];

        /* A shorter window for tennis.
         *
         * Fourteen days back is right for a league playing twice a week. A
         * tennis board carries forty matches a day and each one costs a
         * separate request for its statistics — so eighteen days is several
         * hundred calls in one step, and the step is killed by the server long
         * before it can hand over. That is the half hour with no heartbeat.
         *
         * Four days is enough to catch what finished since the last scan, and
         * the history that matters is filled by the repair above, six days at
         * a time, without the per-match cost.
         */
        $span = ($sport === 'tennis') ? 4 : 14;

        $offsets = [];
        for ($back = 1; $back <= $span; $back++) $offsets[] = -$back;
        for ($ahead = 0; $ahead <= 3; $ahead++) $offsets[] = $ahead;

        foreach ($offsets as $offset) {
            /* Last day's board let go before the next is fetched. PHP frees a
               variable when nothing points at it, and the loop pointed at the
               previous one until it was overwritten — which is one board too
               many held, every time round. */
            unset($board, $events);

            if ($refusals >= 2) break;
            $day = wp_date('Y-m-d', time() + $offset * DAY_IN_SECONDS);
            if ($this->step_deadline_passed()) break;
            /* Stop before the memory runs out, not after.
             *
             * A day's tennis board is a large piece of JSON, and eight days of
             * them were being held at once — the reading reached a hundred and
             * twenty-two megabytes of a hundred and twenty-eight, and the
             * request after that was killed by PHP before it could write
             * anything down. From outside that is a step that never returns.
             *
             * Checked before each board rather than after: once the limit is
             * hit there is no code left running to notice. Eighty per cent
             * leaves room for the one being fetched.
             */
            if (self::memory_tight()) {
                $this->crumb_done();
                break;
            }

            $this->crumb($league . ' — πίνακας ' . $day);
            $board = $this->espn_scoreboard($league, $day);
            if (is_wp_error($board)) { $refusals++; $skipped++; continue; }

            $events = isset($board['events']) ? (array) $board['events'] : [];
            if (!$events) { $empty_days++; continue; }

            foreach ($events as $event) {
                // A team sport puts one match in an event; tennis puts a whole
                // tournament there, with each match a competition inside it.
                // A team sport lists competitions on the event. Tennis groups
                // them by draw first — events[].groupings[].competitions[] —
                // so looking only at the top level found nothing and every
                // match of both tours was fetched and discarded.
                $competitions = self::pick_path($event, 'competitions', []);
                if (!is_array($competitions) || !$competitions) {
                    $competitions = [];
                    foreach ((array) self::pick_path($event, 'groupings', []) as $grouping) {
                        foreach ((array) self::pick_path($grouping, 'competitions', []) as $one) {
                            $competitions[] = $one;
                        }
                    }
                }
                if (!$competitions) { $skipped++; continue; }

                foreach ($competitions as $index => $competition) {
                    /* The clock is checked here as well as once a day.
                     *
                     * Each game below may fetch its own statistics — one HTTP
                     * call apiece — and a day of baseball is fifteen of them.
                     * Checking only between days meant fifteen calls could
                     * start after the deadline had already passed, which is
                     * how the MLB step ran until the server cut it off and the
                     * scan appeared to hang at 58 of 66.
                     *
                     * Stopping mid-day loses nothing: what is stored is
                     * stored, and the next run picks up where this one left
                     * off. */
                    if ($this->step_deadline_passed()) break 2;

                    $id = (string) (isset($competition['id']) ? $competition['id']
                          : (isset($event['id']) ? $event['id'] . '-' . $index : ''));
                    if ($id === '') { $skipped++; continue; }

                    // Tennis returns the whole tournament on every day's board,
                    // so the same match arrives again and again. Trusting the
                    // event's status marks unplayed matches finished, because
                    // the tournament itself is "in progress"; and rewriting the
                    // kickoff each time moves a match to whatever day it was
                    // last seen. Both are settled here: the competition's own
                    // status decides, and a match already stored keeps its date.
                    $own = self::pick_path($competition, 'status.type.completed');
                    $done = $own === null
                        ? (bool) self::pick_path($event, 'status.type.completed')
                        : (bool) $own;
                    $states[$own === null ? 'χωρίς δική του κατάσταση' : ($own ? 'τελειωμένος' : 'προγραμματισμένος')] =
                        (isset($states[$own === null ? 'χωρίς δική του κατάσταση' : ($own ? 'τελειωμένος' : 'προγραμματισμένος')])
                        ? $states[$own === null ? 'χωρίς δική του κατάσταση' : ($own ? 'τελειωμένος' : 'προγραμματισμένος')] : 0) + 1;
                    if ($done && $this->already_have($sport, 'espn', $id)) { $skipped++; continue; }

                    $competitors = isset($competition['competitors']) ? $competition['competitors'] : [];
                    if (count((array) $competitors) < 2) { $skipped++; continue; }

                    $home = $away = null;
                    foreach ($competitors as $side) {
                        if (isset($side['homeAway']) && $side['homeAway'] === 'home') $home = $side;
                        elseif (isset($side['homeAway'])) $away = $side;
                    }
                    // Tennis marks neither player as home; order decides.
                    if (!$home || !$away) {
                        $listed = array_values((array) $competitors);
                        if (count($listed) >= 2) { $home = $listed[0]; $away = $listed[1]; }
                    }
                    if (!$home || !$away) { $skipped++; continue; }

                    $totals = null;
                    if ($done && strpos($league, 'basketball/') === 0) {
                        /* The per-game statistics call, which is the expensive one: one
                           request per match, and a busy day is fifteen of them. Checked
                           here rather than only at the top of the day, because the budget
                           is spent inside this loop, not between days. */
                        /* Ten seconds, not fifteen, before the per-match call.
                     *
                     * The check has to leave room for the request it is about
                     * to allow: one that starts at fourteen seconds and takes
                     * eight finishes at twenty-two, past whatever the server
                     * permits, and the process is killed mid-flight — which
                     * looks from outside like a step that never returns. */
                    if ($this->step_deadline_passed()
                        || (isset($this->step_started)
                            && (time() - $this->step_started) > 10)) break 3;

                        $summary = $this->espn_summary($league, isset($event['id']) ? $event['id'] : $id);
                        $totals = is_wp_error($summary) ? null : $this->espn_totals($summary);
                    }

                    /* espn_score(), not the bare field.
                     *
                     * "score" is what team sports send. Tennis sends sets with
                     * a winner flag on each and nothing at this path — so five
                     * thousand finished matches were stored with no result,
                     * the form builder had nothing to work from, and no
                     * suggestion could ever be made.
                     *
                     * espn_score() handles all three shapes and was already
                     * used by the other reader, twenty lines away. This one
                     * never called it. */
                    $hs = self::espn_score($home);
                    $as = self::espn_score($away);

                    $this->store_game($sport, 'espn', [
                        'id'         => $id,
                        /* The tour the event says it belongs to, not the one
                         * we happened to ask for.
                         *
                         * ESPN answers the ATP board and the WTA board with
                         * the same day's tennis, so every fixture was written
                         * twice and the second call — WTA — overwrote the
                         * first. That is why the men's draw shows under WTA
                         * and the ATP list has finished matches but no
                         * upcoming ones: the finished ones are skipped on the
                         * second pass and survive; the upcoming ones are not.
                         *
                         * The event carries its own competition name. Where it
                         * does, it decides; where it does not, the board we
                         * asked for stands, which is no worse than before. */
                        'league'     => $league,
                        'league_name'=> self::tour_name($event, $competition, $label),
                        'country'    => '',
                        /* competitor_key(), not the raw path.
                         *
                         * It was written for exactly this and never called
                         * from anywhere — so every tennis player kept being
                         * stored as the bare prefix with nothing after it,
                         * and a blank matches every other blank. The history
                         * lookup then answered "a thousand past matches" for
                         * every player alive, which the model rightly refused
                         * to believe.
                         *
                         * Six times in one day a fix has been written into a
                         * function nothing calls. This is the seventh, and it
                         * is now wired. */
                        'home_id'    => (string) self::competitor_key($home),
                        'home_name'  => (string) self::pick_path($home, 'team.displayName',
                                        self::pick_path($home, 'athlete.displayName',
                                        self::pick_path($home, 'athlete.shortName', ''))),
                        'away_id'    => (string) self::competitor_key($away),
                        'away_name'  => (string) self::pick_path($away, 'team.displayName',
                                        self::pick_path($away, 'athlete.displayName',
                                        self::pick_path($away, 'athlete.shortName', ''))),
                        'kickoff'    => gmdate('Y-m-d H:i:s', strtotime((string) (
                                        // A tennis "event" is the whole tournament and its date
                                        // is the day the tournament began — often a week ago. Using
                                        // it stamped every match of today with a date in the past,
                                        // so nothing was ever upcoming and everything landed in
                                        // history. The day actually being read is the right answer
                                        // when a match carries no time of its own.
                                        // ESPN hands back a tournament's whole draw on every
                                        // day it runs, so a match seen on five days was rewritten
                                        // five times with five different dates — the last read
                                        // winning. A match's own date is the only one that means
                                        // anything; without it the match is not dated at all and
                                        // is better skipped than misfiled.
                                        isset($competition['date']) ? $competition['date']
                                        : (isset($event['date']) && strpos($league, 'tennis/') !== 0
                                            ? $event['date'] : '')))),
                        'status'     => $done ? 'FT' : 'NS',
                        'finished'   => $done ? 1 : 0,
                        'home_score' => ($done && is_numeric($hs)) ? (int) $hs : null,
                        'away_score' => ($done && is_numeric($as)) ? (int) $as : null,
                    ], $totals);
                    $stored++;
                }
            }
        }

        $parts = [];
        foreach ($states as $state => $n) $parts[] = $state . ' ×' . $n;
        $summary = $stored . ' αγώνες, ' . $skipped . ' αγνοήθηκαν, '
                 . $empty_days . ' μέρες χωρίς αγώνες'
                 . ($refusals ? ', ' . $refusals . ' αρνήσεις' : '')
                 . ($parts ? ' · κατάσταση: ' . implode(' | ', $parts) : '');
        $this->mark('espn', $stored > 0 || $refusals === 0, $label . ': ' . $summary);
        $this->outcome('espn:' . $league, $summary);
        $this->crumb_done();
        return $stored;
    }

    /* ---------------------------------------------------------------- probe */

    /**
     * Ask a source to prove it works, and print what came back when it does
     * not. Guessing at a response shape has cost this project several releases;
     * the answer belongs on screen, not in an inference.
     */
    public function probe($key) {
        $show = function ($thing) {
            $json = wp_json_encode($thing, JSON_UNESCAPED_UNICODE);
            return $json === false ? '' : mb_substr($json, 0, 400, 'UTF-8');
        };

        // "espn" on its own means every league, which is 180 requests and
        // more than one step can finish. The queue now asks for one league at
        // a time as "espn:basketball/nba", and the whole set only when
        // something calls for it directly.
        if (strpos($key, 'espn:') === 0) {
            $only = substr($key, 5);
            $all = self::espn_all();
            if (!isset($all[$only])) return 0;
            return $this->ingest_espn_league($only, $all[$only][0], $all[$only][1]);
        }

        if ($key === 'espn') {
            // The cap used to be a single total across every league, and the
            // basketball ones come first alphabetically — they consumed it and
            // tennis, hockey and baseball were never reached at all. Each
            // league now gets its own share.
            foreach (self::espn_all() as $league => $meta) {
                list($label, $sport) = $meta;
                // Six minutes of requests killed the step before it could
                // report anything. Three days back, three forward, and a
                // league that refuses twice in a row is left alone.
                $refusals = 0;
                for ($back = 1; $back <= 240; $back += 1) {
                    if ($back > 8 && $back % 30 !== 0) continue;  // recent days, then monthly hops
                    if ($this->step_deadline_passed()) break;
                    $board = $this->espn_scoreboard($league, wp_date('Y-m-d', time() - $back * DAY_IN_SECONDS));
                    if (is_wp_error($board) || empty($board['events'])) continue;

                    foreach ($board['events'] as $event) {
                        $done = !empty($event['status']['type']['completed']);
                        if (!$done || empty($event['id'])) continue;
                        $summary = $this->espn_summary($league, $event['id']);
                        if (is_wp_error($summary)) continue;
                        $totals = $this->espn_totals($summary);
                        if ($totals) {
                            return ['ok' => true,
                                    'note' => $label . ' — διαβάστηκε το box score του αγώνα '
                                            . (isset($event['name']) ? $event['name'] : $event['id']) . '.',
                                    'sample' => $show($totals)];
                        }
                    }
                }
            }
            return ['ok' => false, 'note' => 'Καμία διοργάνωση δεν επέστρεψε ολοκληρωμένο αγώνα με στατιστικά.', 'sample' => ''];
        }

        if ($key === 'highlightly') {
            $leagues = $this->hl_leagues();
            if (is_wp_error($leagues)) return ['ok' => false, 'note' => $leagues->get_error_message(), 'sample' => ''];
            $list = self::unwrap($leagues);
            if (!is_array($list) || !$list) {
                return ['ok' => false, 'note' => 'Απάντησε αλλά χωρίς πρωταθλήματα.', 'sample' => $show($leagues)];
            }

            // Sample several matches, not the first that turns up. The first
            // attempt tested a Chilean second-division fixture and reported the
            // whole source dead because it had no box score -- which no source
            // has, for that match. An empty statistics list means nothing until
            // a game that ought to have one has been tried.
            $checked = 0;
            $withstats = 0;
            $good = null;
            $names = [];

            for ($back = 1; $back <= 5 && $checked < 10; $back++) {
                $rows = $this->hl_matches(wp_date('Y-m-d', time() - $back * DAY_IN_SECONDS));
                if (is_wp_error($rows)) continue;
                $rows = self::unwrap($rows);
                if (!is_array($rows) || !$rows) continue;

                // Bigger competitions first: they are the ones that publish.
                usort($rows, function ($a, $b) {
                    $rank = function ($m) {
                        $name = mb_strtolower((string) self::pick_path($m, 'league.name', ''), 'UTF-8');
                        foreach (['nba', 'euroleague', 'eurocup', 'acb', 'ncaa', 'lega', 'bbl',
                                  'pro a', 'nbl', 'b.league', 'cba', 'kbl', 'basket league'] as $i => $tag) {
                            if (strpos($name, $tag) !== false) return $i;
                        }
                        return 99;
                    };
                    return $rank($a) - $rank($b);
                });

                foreach ($rows as $match) {
                    if ($checked >= 10) break;
                    if (empty($match['id'])) continue;
                    $checked++;
                    $names[] = (string) self::pick_path($match, 'league.name', '—');
                    $stats = $this->hl_stats($match['id']);
                    if (is_wp_error($stats)) continue;
                    $totals = $this->hl_totals($stats);
                    if ($totals) {
                        $withstats++;
                        if ($good === null) $good = ['league' => end($names), 'totals' => $totals];
                    }
                }
            }

            if ($good) {
                return ['ok' => true,
                        'note' => count($list) . ' πρωταθλήματα· ' . $withstats . ' από ' . $checked
                                . ' αγώνες είχαν αναλυτικά στατιστικά. Παράδειγμα: ' . $good['league'],
                        'sample' => $show($good['totals'])];
            }
            if (!$checked) {
                return ['ok' => false, 'note' => count($list) . ' πρωταθλήματα, αλλά κανένας αγώνας τις τελευταίες 5 ημέρες.', 'sample' => ''];
            }
            return ['ok' => false,
                    'note' => 'Δοκιμάστηκαν ' . $checked . ' αγώνες και κανένας δεν είχε αναλυτικά '
                            . 'στατιστικά — φαίνεται κλειδωμένο στο δωρεάν επίπεδο.',
                    'sample' => $show(array_slice(array_unique($names), 0, 8))];
        }

        if ($key === 'euroleague' || $key === 'eurocup') {
            $competition = $key === 'euroleague' ? 'E' : 'U';
            $games = $this->el_games($competition);
            if (is_wp_error($games)) return ['ok' => false, 'note' => $games->get_error_message(), 'sample' => ''];
            if (!$games) {
                return ['ok' => false, 'note' => 'Καμία εγγραφή — ίσως λάθος σεζόν (' . $this->season_code($competition) . ').', 'sample' => ''];
            }

            // The newest game that was actually played: an unplayed fixture has
            // no box score to read.
            $played = [];
            foreach ($games as $game) {
                if (!is_array($game)) continue;
                if (!empty($game['played']) || isset($game['homeScore']) || isset($game['localScore'])) $played[] = $game;
            }
            $pick = $played ? end($played) : end($games);
            $code = null;
            foreach (['gameCode', 'code', 'gamecode'] as $field) {
                if (isset($pick[$field])) { $code = $pick[$field]; break; }
            }
            if ($code === null) {
                return ['ok' => false, 'note' => 'Ήρθαν αγώνες αλλά χωρίς κωδικό.', 'sample' => $show($pick)];
            }

            $box = $this->el_boxscore($competition, $code);
            if (is_wp_error($box)) {
                return ['ok' => false, 'note' => 'Οι αγώνες ήρθαν, το box score όχι: ' . $box->get_error_message(), 'sample' => ''];
            }
            $totals = $this->el_totals($box);
            if (!$totals) {
                return ['ok' => false, 'note' => 'Το box score ήρθε αλλά δεν αναγνωρίστηκαν τα σύνολα.', 'sample' => $show($box)];
            }
            return ['ok' => true, 'note' => count($games) . ' αγώνες· box score διαβάστηκε.', 'sample' => $show($totals)];
        }

        /* Big Balls και BALLDONTLIE: η δοκιμή δεν τις ήξερε καθόλου.
         *
         * Η ingest_source() τις δρομολογεί κανονικά και η σελίδα έχει πεδίο
         * κλειδιού για την καθεμία — αλλά εδώ δεν υπήρχε κλάδος, οπότε το
         * κουμπί «Δοκιμή» έπεφτε στο τελικό «Άγνωστη πηγή» και τις έδειχνε
         * «δεν λειτουργεί». Ένα κλειδί που δούλευε μια χαρά φαινόταν νεκρό,
         * και ο μόνος τρόπος να το διαπιστώσεις ήταν ολόκληρη σάρωση.
         *
         * Οι δοκιμές χτυπάνε ΤΟ ΙΔΙΟ endpoint με τις ίδιες κεφαλίδες που
         * χρησιμοποιεί η εισαγωγή. Μια δοκιμή που ρωτάει αλλού από ό,τι η
         * πραγματική κλήση δεν αποδεικνύει τίποτα.
         *
         * Το Big Balls θέλει «Bearer» μπροστά από το κλειδί, το BALLDONTLIE
         * σκέτο το κλειδί. Είναι διαφορετικοί πάροχοι και η διαφορά είναι
         * ήδη σημειωμένη μέσα στον κώδικα της εισαγωγής. */
        if ($key === 'bigballs' || $key === 'balldontlie') {
            $src_conf  = $this->settings();
            $src_slot  = $key === 'bigballs' ? 'bb_key' : 'bdl_key';
            $src_token = trim((string) (isset($src_conf[$src_slot])
                                        ? $src_conf[$src_slot] : ''));

            if ($src_token === '') {
                return ['ok' => false,
                        'note' => 'Δεν έχει οριστεί κλειδί για αυτή την πηγή.',
                        'sample' => ''];
            }

            if ($key === 'bigballs') {
                $src_url = 'https://api.bigballsdata.com/v1/matches?sport=basketball';
                $src_headers = ['Authorization' => 'Bearer ' . $src_token,
                                'Accept'        => 'application/json'];
            } else {
                $src_url = 'https://api.balldontlie.io/nba/v1/games?per_page=5&dates[]='
                         . rawurlencode(wp_date('Y-m-d', time() - DAY_IN_SECONDS));
                $src_headers = ['Authorization' => $src_token,
                                'Accept'        => 'application/json'];
            }

            $src_res = wp_remote_get($src_url, ['timeout' => 25, 'headers' => $src_headers]);

            if (is_wp_error($src_res)) {
                return ['ok' => false,
                        'note' => 'Δεν απάντησε: ' . $src_res->get_error_message(),
                        'sample' => ''];
            }

            $src_code = (int) wp_remote_retrieve_response_code($src_res);
            $src_raw  = (string) wp_remote_retrieve_body($src_res);
            $src_body = json_decode($src_raw, true);

            /* Το κείμενο της απάντησης μπαίνει στο δείγμα όταν κάτι πάει
               στραβά. Ένα σκέτο «401» δεν λέει αν φταίει το κλειδί, η μορφή
               του ή το πακέτο· το μήνυμα του παρόχου το λέει. */
            if ($src_code !== 200 || !is_array($src_body)) {
                return ['ok' => false,
                        'note' => 'HTTP ' . $src_code . ' — το κλειδί δεν έγινε δεκτό '
                                . 'ή άλλαξε η διεύθυνση του παρόχου.',
                        'sample' => mb_substr($src_raw, 0, 400, 'UTF-8')];
            }

            $src_rows = isset($src_body['data']) && is_array($src_body['data'])
                      ? $src_body['data'] : $src_body;
            $src_n = is_array($src_rows) ? count($src_rows) : 0;

            if (!$src_n) {
                return ['ok' => false,
                        'note' => 'Το κλειδί έγινε δεκτό (HTTP 200) αλλά δεν ήρθε κανένας αγώνας.',
                        'sample' => $show($src_body)];
            }

            /* ΑΝΙΧΝΕΥΤΗΣ ΑΓΟΡΩΝ — ρωτάει αντί να μαντεύει.
             *
             * Το ερώτημα είναι αν ο πάροχος δίνει αποδόσεις, και ιδίως αν
             * δίνει ριμπάουντ και ασίστ ομάδας: το μοντέλο τις υπολογίζει
             * ήδη και τους λείπει μόνο τιμή. Οι οδηγίες του παρόχου είναι
             * πίσω από σύνδεση και δεν φαίνονται από εδώ.
             *
             * Τρεις πιθανές διευθύνσεις, μία κλήση η καθεμία, μόνο ανάγνωση.
             * Καταγράφεται ο κωδικός απάντησης και τα πρώτα bytes αυτούσια —
             * ό,τι κι αν είναι, θα το δούμε αντί να το υποθέσουμε. Αν καμία
             * δεν απαντήσει 200, το ξέρουμε οριστικά σε ένα πάτημα.
             *
             * Τρεις κλήσεις από τις 1.000 (ή 2.000) της ημέρας. */
            if ($key === 'bigballs') {
                $probe_bits = [];

                foreach (['odds', 'markets', 'props'] as $where) {
                    $try = wp_remote_get(
                        'https://api.bigballsdata.com/v1/' . $where . '?sport=basketball',
                        ['timeout' => 15, 'headers' => [
                            'Authorization' => 'Bearer ' . $src_token,
                            'Accept'        => 'application/json',
                        ]]);

                    if (is_wp_error($try)) {
                        $probe_bits[] = $where . ': ' . $try->get_error_message();
                        continue;
                    }

                    $try_code = (int) wp_remote_retrieve_response_code($try);
                    $try_body = trim((string) wp_remote_retrieve_body($try));

                    $probe_bits[] = $where . ': HTTP ' . $try_code . ' · '
                                  . mb_substr($try_body, 0, 220, 'UTF-8');
                }

                if ($probe_bits) {
                    $this->note('Big Balls · ανιχνευτής αγορών → '
                              . implode('  ||  ', $probe_bits));
                }

                return ['ok' => true,
                        'note' => $src_n . ' αγώνες ήρθαν με αυτό το κλειδί. '
                                . 'Ο ανιχνευτής αγορών έγραψε την απάντηση '
                                . 'κάθε διεύθυνσης στο ημερολόγιο.',
                        'sample' => implode("\n", $probe_bits)];
            }

            return ['ok' => true,
                    'note' => $src_n . ' αγώνες ήρθαν με αυτό το κλειδί.',
                    'sample' => $show(array_slice((array) $src_rows, 0, 2))];
        }

        return ['ok' => false, 'note' => 'Άγνωστη πηγή.', 'sample' => ''];
    }

    /* ---------------------------------------------------------------- admin */

    public function register_menu() {
        add_submenu_page('emenu-dp82', 'Πηγές μπάσκετ', 'Πηγές μπάσκετ', 'manage_options',
            'emenu-dp82-hoops', [$this, 'page_sources']);
    }

    public function page_sources() {
        if (!current_user_can('manage_options')) return;
        $s = $this->settings();
        $result = get_transient('emenu_dp82_hoops_probe');
        if ($result) delete_transient('emenu_dp82_hoops_probe');
        ?>
        <div class="wrap">
          <h1>Εξωτερικές πηγές</h1>
          <p class="description" style="max-width:840px;">
            Το δωρεάν πλάνο του API-Sports δεν δίνει ιστορικά αναλυτικά στατιστικά, οπότε ριμπάουντ
            και ασίστ έρχονται από τις ίδιες τις διοργανώσεις. Οι δοκιμές βρίσκουν μόνες τους τον
            πιο πρόσφατο αγώνα — δεν χρειάζεται να συμπληρώσεις ημερομηνία. Όποια πηγή σπάσει,
            οι αγορές της εξαφανίζονται αντί να βγάζουν παλιά ή λάθος νούμερα.
          </p>

          <?php if ($result): ?>
            <div class="notice notice-<?php echo !empty($result['ok']) ? 'success' : 'error'; ?>">
              <p><strong><?php echo esc_html($result['key']); ?>:</strong> <?php echo esc_html($result['note']); ?></p>
              <?php if (!empty($result['sample'])): ?>
                <p><code style="display:block;white-space:pre-wrap;word-break:break-all;"><?php
                  echo esc_html($result['sample']); ?></code></p>
              <?php endif; ?>
            </div>
          <?php endif; ?>

          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="emenu_dp82_hoops_save">
            <?php wp_nonce_field('emenu_dp82_hoops_save'); ?>

            <table class="widefat striped" style="max-width:980px;">
              <thead><tr>
                <th style="width:60px;">Ενεργή</th><th>Πηγή</th><th style="width:180px;">Κατάσταση</th><th style="width:110px;">Δοκιμή</th>
              </tr></thead>
              <tbody>
              <?php foreach (self::sources() as $key => $source): $health = $this->health($key); ?>
                <tr>
                  <td><input type="checkbox" name="sources[]" value="<?php echo esc_attr($key); ?>"
                             <?php checked($this->enabled($key)); ?>></td>
                  <td>
                    <strong><?php echo esc_html($source['label']); ?></strong>
                    <?php if (empty($source['official'])): ?><span style="color:#996800;"> · ανεπίσημη</span><?php endif; ?>
                    <br><span class="description"><?php echo esc_html($source['note']); ?></span>
                    <?php if ($health && !empty($health['note'])): ?>
                      <br><span class="description" style="color:#646970;"><?php echo esc_html($health['note']); ?></span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if (!$health): ?>
                      <span style="color:#8c8f94;">δεν δοκιμάστηκε</span>
                    <?php else: ?>
                      <span style="color:<?php echo !empty($health['ok']) ? '#1a7f37' : '#b32d2e'; ?>;">
                        <?php echo !empty($health['ok']) ? '✔ λειτουργεί' : '✘ δεν λειτουργεί'; ?>
                      </span>
                      <br><span class="description"><?php echo esc_html($health['checked']); ?></span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <a class="button" href="<?php echo esc_url(wp_nonce_url(
                      admin_url('admin-post.php?action=emenu_dp82_hoops_probe&source=' . $key), 'emenu_dp82_hoops_probe')); ?>">Δοκιμή</a>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>

            <h2 style="margin-top:24px;">Κλειδί Highlightly</h2>
            <p class="description" style="max-width:840px;">
              Δωρεάν εγγραφή στο highlightly.net. Ένα κλειδί ανοίγει Ελλάδα, Ισπανία, Ιταλία,
              Γερμανία, Γαλλία, Αυστραλία, Ιαπωνία, Κίνα, Κορέα, NCAA και FIBA — χωρίς να
              προσθέτεις πρωτάθλημα ένα-ένα.
            </p>
            <input type="text" name="hl_key" class="regular-text" autocomplete="off"
                   value="<?php echo esc_attr($s['hl_key']); ?>">

            <p style="margin-top:18px;"><strong>Big Balls Sports Data</strong></p>
            <p class="description" style="max-width:760px;">
              Δωρεάν 1.000 αιτήματα την ημέρα, 2.000 με σύνδεση GitHub, και 100 το
              λεπτό — το μεγαλύτερο δωρεάν όριο που βρέθηκε. Ένα σχήμα για όλα τα
              αθλήματα, ποδόσφαιρο και μπάσκετ μαζί. Εγγραφή στο bigballsdata.com.
            </p>
            <input type="text" name="bb_key" class="regular-text" autocomplete="off"
                   value="<?php echo esc_attr($s['bb_key']); ?>">

            <p style="margin-top:18px;"><strong>BALLDONTLIE</strong></p>
            <p class="description" style="max-width:760px;">
              Δωρεάν πακέτο. NBA, WNBA, NCAA, και στο ποδόσφαιρο Premier League,
              La Liga, Serie A, Bundesliga, Ligue 1, Champions League και MLS.
              Εγγραφή στο balldontlie.io.
            </p>
            <input type="text" name="bdl_key" class="regular-text" autocomplete="off"
                   value="<?php echo esc_attr($s['bdl_key']); ?>">

            <p class="description" style="max-width:760px;margin-top:10px;">
              Τα κλειδιά αποθηκεύονται τώρα· η σύνδεσή τους με τη σάρωση γίνεται
              σε επόμενο βήμα, αφού επιβεβαιωθεί ότι το καθένα απαντάει. Ένα
              κενό πεδίο δεν προκαλεί καμία κλήση.
            </p>

            <p style="margin-top:16px;">
              <label>Σεζόν, μόνο ως παράκαμψη αν η αυτόματη επιλογή αστοχήσει:
                <input type="text" name="season" value="<?php echo esc_attr($s['season']); ?>"
                       style="width:90px;" placeholder="2025">
              </label>
            </p>
            <?php submit_button('Αποθήκευση'); ?>
          </form>
        </div>
        <?php
    }

    public function handle_probe() {
        if (!current_user_can('manage_options')) wp_die('Δεν επιτρέπεται.');
        check_admin_referer('emenu_dp82_hoops_probe');
        $key = isset($_GET['source']) ? sanitize_key(wp_unslash($_GET['source'])) : '';

        $result = $this->probe($key);
        $this->mark($key, $result['ok'], $result['note']);
        $result['key'] = $key;
        set_transient('emenu_dp82_hoops_probe', $result, 60);

        wp_safe_redirect(admin_url('admin.php?page=emenu-dp82-hoops'));
        exit;
    }

    public function handle_save() {
        if (!current_user_can('manage_options')) wp_die('Δεν επιτρέπεται.');
        check_admin_referer('emenu_dp82_hoops_save');
        $s = $this->settings();

        $ticked = isset($_POST['sources']) && is_array($_POST['sources'])
            ? array_map('sanitize_key', wp_unslash($_POST['sources'])) : [];
        $off = [];
        foreach (array_keys(self::sources()) as $key) {
            if (!in_array($key, $ticked, true)) $off[] = $key;
        }
        $s['disabled'] = $off;
        $s['hl_key'] = isset($_POST['hl_key']) ? sanitize_text_field(wp_unslash($_POST['hl_key'])) : '';
        $s['bb_key']  = isset($_POST['bb_key'])  ? sanitize_text_field(wp_unslash($_POST['bb_key']))  : '';
        $s['bdl_key'] = isset($_POST['bdl_key']) ? sanitize_text_field(wp_unslash($_POST['bdl_key'])) : '';
        $s['season'] = isset($_POST['season']) ? preg_replace('/[^0-9]/', '', (string) wp_unslash($_POST['season'])) : '';

        update_option(self::SOURCES_OPT, $s);
        wp_safe_redirect(admin_url('admin.php?page=emenu-dp82-hoops'));
        exit;
    }
}

EMenu_DP82_Hoops::instance();
