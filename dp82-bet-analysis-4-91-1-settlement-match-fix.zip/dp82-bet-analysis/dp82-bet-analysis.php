<?php
/**
 * Plugin Name: SportIQ
 * Description: Ανάλυση αγώνων και προτάσεις, ανεξάρτητα από τα μενού εστιατορίων.
 * Version: 4.91.1
 * Author: Διαμαντής Παναγιώτης
 *
 * Why this is its own plugin now.
 *
 * It lived inside e-Menu CMS, which meant a mistake in the odds reader took
 * the restaurant menus down with it — and it did, in the middle of a season,
 * on a day when the shops were open. The betting side changes weekly and
 * touches a live third-party feed; the menus barely change and must not go
 * down. Two things with opposite risk profiles do not belong in one file
 * that WordPress loads as a unit.
 *
 * Nothing about the data moves. The tables keep their names —
 * wp_emenu_dp82_* — so every fixture, signal and price already stored is
 * exactly where it was. This is a change of container, not of contents.
 */

if (!defined('ABSPATH')) exit;

define('DP82_VERSION', '4.91.1');

/**
 * Catch this plugin's own fatal error and write it down.
 *
 * Activation failed with "triggered a fatal error" and nothing else — the
 * message WordPress shows when it detects a crash but the error output has
 * already gone. Two days of reading the file found nothing, because the fault
 * is at run time and no amount of reading finds those.
 *
 * WP_DEBUG lives in wp-config.php and a plugin cannot set it for its own
 * activation. But a shutdown function still runs after a fatal, and
 * error_get_last() still knows what happened — so this catches it, writes it
 * to a plain file, and shows it on screen.
 *
 * It reads error state and writes one file. It cannot itself break anything,
 * and it only reports on errors whose file lives in this plugin's folder —
 * somebody else's crash is not ours to shout about.
 */
register_shutdown_function(function () {
    $e = error_get_last();
    if (!$e) return;

    $fatal = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
    if (!in_array($e['type'], $fatal, true)) return;

    // Only ours.
    if (strpos((string) ($e['file'] ?? ''), 'dp82-bet-analysis') === false) return;

    $text = "DP82 σφάλμα\n"
          . "όταν : " . date('Y-m-d H:i:s') . "\n"
          . "τύπος: " . $e['type'] . "\n"
          . "αρχείο: " . $e['file'] . "\n"
          . "γραμμή: " . $e['line'] . "\n"
          . "μήνυμα: " . $e['message'] . "\n"
          . "PHP   : " . PHP_VERSION . "\n";

    /* Into uploads, which is writable and reachable from a browser — the
       plugin folder is not, the server refuses direct access to it. */
    if (function_exists('wp_upload_dir')) {
        $up = wp_upload_dir();
        if (!empty($up['basedir'])) {
            @file_put_contents(rtrim($up['basedir'], '/') . '/dp82-error.txt', $text);
        }
    }

    @error_log($text);

    // And on screen, for the person who just pressed Activate.
    if (!headers_sent()) {
        echo '<pre style="background:#fff;border:2px solid #c00;padding:14px;'
           . 'font:13px monospace;white-space:pre-wrap;">'
           . htmlspecialchars($text) . '</pre>';
    }
});
define('DP82_DIR', plugin_dir_path(__FILE__));
define('DP82_URL', plugin_dir_url(__FILE__));

/**
 * Refuse to load twice.
 *
 * If e-Menu CMS is still carrying its own copy, both would declare the same
 * class and PHP would stop the site dead — the exact failure this separation
 * exists to prevent, caused by the separation itself.
 *
 * So: whichever loads first wins, and this one says plainly what to do about
 * it rather than crashing or, worse, half-working.
 */
add_action('plugins_loaded', function () {

    if (class_exists('EMenu_DP82')) {
        add_action('admin_notices', function () {
            echo '<div class="notice notice-warning"><p><strong>SportIQ:</strong> '
               . 'το module υπάρχει ακόμη μέσα στο e-Menu CMS, οπότε αυτό το πρόσθετο '
               . 'δεν φορτώθηκε. Ενημερώστε πρώτα το e-Menu CMS στην έκδοση που δεν '
               . 'το περιλαμβάνει, και μετά ενεργοποιήστε ξανά αυτό.</p></div>';
        });
        return;
    }

    require_once DP82_DIR . 'includes/class-emenu-dp82.php';
    require_once DP82_DIR . 'includes/class-emenu-dp82-hoops.php';
    require_once DP82_DIR . 'includes/class-emenu-dp82-clubs.php';

    if (class_exists('EMenu_DP82')) {
        EMenu_DP82::instance();
    }

    if (class_exists('EMenu_DP82_Hoops')) {
        EMenu_DP82_Hoops::instance();
    }

}, 5);

/**
 * Activation does nothing but say "yes".
 *
 * The first version created tables and flushed rewrite rules here, and
 * WordPress refused to activate with "triggered a fatal error" — which tells
 * you that something went wrong and nothing about what, because the screen
 * that reports it is the screen that cannot render anything else.
 *
 * An activation hook is the worst place to do work. It runs once, in a request
 * nobody is watching, and any failure becomes a plugin that will not turn on
 * rather than a plugin that says what is wrong.
 *
 * So it sets a flag. The real work happens on the next admin page load, inside
 * a try/catch, where a failure can be reported in words instead of a blank
 * refusal.
 */
register_activation_hook(__FILE__, function () {
    update_option('dp82_needs_setup', '1', false);
});

register_deactivation_hook(__FILE__, function () {
    /* Only the scheduled events, and only if the class is loadable. Leaving a
       cron event behind for a plugin that is switched off means it fires into
       nothing every hour for as long as the site lives. */
    try {
        if (!class_exists('EMenu_DP82')) {
            require_once DP82_DIR . 'includes/class-emenu-dp82.php';
        }
        if (method_exists('EMenu_DP82', 'deactivate')) {
            EMenu_DP82::deactivate();
        }
    } catch (\Throwable $e) {
        // Nothing to do about it here, and refusing to deactivate would be
        // worse than a leftover cron event.
    }
});

/**
 * The setup that activation used to do, where it can report itself.
 */
add_action('admin_init', function () {
    if (get_option('dp82_needs_setup') !== '1') return;
    if (!current_user_can('activate_plugins')) return;

    try {
        if (!class_exists('EMenu_DP82')) {
            require_once DP82_DIR . 'includes/class-emenu-dp82.php';
        }

        if (method_exists('EMenu_DP82', 'activate')) {
            EMenu_DP82::activate();
        }

        delete_option('dp82_needs_setup');
        update_option('dp82_setup_error', '', false);

    } catch (\Throwable $e) {
        /* Kept, and shown. A message naming the file and the line is the
           difference between a fix and another afternoon of guessing. */
        update_option('dp82_setup_error',
            $e->getMessage() . ' — ' . $e->getFile() . ':' . $e->getLine(), false);
        delete_option('dp82_needs_setup');
    }
});

add_action('admin_notices', function () {
    $err = get_option('dp82_setup_error', '');
    if ($err === '' || !current_user_can('activate_plugins')) return;

    echo '<div class="notice notice-error"><p><strong>DP82:</strong> '
       . 'η αρχικοποίηση απέτυχε.<br><code>' . esc_html($err) . '</code></p></div>';
});

