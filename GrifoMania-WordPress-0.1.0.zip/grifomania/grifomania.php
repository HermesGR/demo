<?php
/**
 * Plugin Name: GrifoMania
 * Description: A bilingual puzzle-adventure game prototype. Add [grifomania] to a page.
 * Version: 0.1.0
 * Author: GrifoMania
 * Text Domain: grifomania
 */

if (!defined('ABSPATH')) {
    exit;
}

define('GRIFOMANIA_VERSION', '0.1.0');
define('GRIFOMANIA_URL', plugin_dir_url(__FILE__));

function grifomania_register_assets() {
    wp_register_style(
        'grifomania-game',
        GRIFOMANIA_URL . 'assets/game.css',
        array(),
        GRIFOMANIA_VERSION
    );
    wp_register_script(
        'grifomania-game',
        GRIFOMANIA_URL . 'assets/game.js',
        array(),
        GRIFOMANIA_VERSION,
        true
    );
}
add_action('wp_enqueue_scripts', 'grifomania_register_assets');

function grifomania_shortcode($atts = array()) {
    wp_enqueue_style('grifomania-game');
    wp_enqueue_script('grifomania-game');

    $config = array(
        'version' => GRIFOMANIA_VERSION,
        'storageKey' => 'grifomania_progress_v1',
        'strings' => array(
            'el' => array(
                'eyebrow' => 'ΤΟ ΜΥΣΤΙΚΟ ΤΩΝ 7 ΠΥΛΩΝ',
                'title' => 'Η Πρώτη Πύλη',
                'intro' => 'Ένα αρχαίο σύμβολο ξύπνησε. Για να ανοίξεις την πύλη, πρέπει να αποδείξεις ότι παρατηρείς, σκέφτεσαι και συνδέεις τα στοιχεία.',
                'start' => 'Ξεκίνα την αποστολή',
                'continue' => 'Συνέχισε την αποστολή',
                'level' => 'ΕΠΙΠΕΔΟ 1',
                'challenge' => 'ΔΟΚΙΜΑΣΙΑ',
                'of' => 'από',
                'points' => 'Πόντοι',
                'hint' => 'Υπόδειξη',
                'check' => 'Έλεγχος απάντησης',
                'next' => 'Επόμενη δοκιμασία',
                'finish' => 'Ολοκλήρωση επιπέδου',
                'correct' => 'Σωστά! Το στοιχείο αποκαλύφθηκε.',
                'wrong' => 'Δεν είναι αυτή η λύση. Δοκίμασε ξανά!',
                'hint1' => 'Κοίτα πόσο αυξάνεται κάθε φορά ο αριθμός.',
                'hint2' => 'Μέτρησε τα αντικείμενα σε κάθε ομάδα.',
                'hint3' => 'Δεν χρειάζεται να μετακινήσεις τίποτα. Σκέψου τι έχεις μπροστά σου.',
                'p1title' => 'Ο κώδικας των αριθμών',
                'p1text' => 'Στην πέτρινη πλάκα είναι χαραγμένη η ακολουθία: 2, 4, 8, 16, __. Ποιος αριθμός συμπληρώνει τον κώδικα;',
                'p2title' => 'Το σημάδι που περισσεύει',
                'p2text' => 'Τρία σύμβολα ακολουθούν τον ίδιο κανόνα και ένα όχι. Ποιο είναι διαφορετικό;',
                'p3title' => 'Η τελευταία ερώτηση',
                'p3text' => 'Όσο περισσότερο αφαιρείς από εμένα, τόσο μεγαλύτερος γίνομαι. Τι είμαι;',
                'answer' => 'Απάντηση',
                'placeholder' => 'Γράψε την απάντησή σου…',
                'options' => array('Κύκλος', 'Τρίγωνο', 'Τετράγωνο', 'Αστέρι'),
                'puzzle2note' => 'Διάλεξε ένα σύμβολο.',
                'successTitle' => 'Η πύλη άνοιξε!',
                'successText' => 'Ολοκλήρωσες την πρώτη δοκιμασία του GrifoMania. Κάθε πύλη κρύβει ένα μεγαλύτερο μυστικό.',
                'restart' => 'Παίξε ξανά το επίπεδο',
                'progress' => 'Η πρόοδός σου αποθηκεύεται σε αυτή τη συσκευή.',
                'saved' => 'Η πρόοδός σου αποθηκεύτηκε.',
                'language' => 'Γλώσσα',
                'reset' => 'Μηδενισμός προόδου',
                'resetConfirm' => 'Θέλεις σίγουρα να μηδενίσεις την πρόοδό σου;',
                'step' => 'Βήμα',
                'complete' => 'Ολοκληρωμένο',
                'notStarted' => 'Δεν έχει ξεκινήσει',
                'guestNotice' => 'Παίζεις ως επισκέπτης. Η πρόοδός σου αποθηκεύεται τοπικά σε αυτή τη συσκευή. Η σύνδεση Google/Apple και ο συγχρονισμός λογαριασμού θα προστεθούν σε επόμενο στάδιο.',
                'p2shape' => 'Σχήμα',
                'back' => 'Πίσω στην αρχή'
            ),
            'en' => array(
                'eyebrow' => 'THE SECRET OF THE 7 GATES',
                'title' => 'The First Gate',
                'intro' => 'An ancient symbol has awakened. To open the gate, prove that you can observe, think, and connect the clues.',
                'start' => 'Start the quest',
                'continue' => 'Continue quest',
                'level' => 'LEVEL 1',
                'challenge' => 'CHALLENGE',
                'of' => 'of',
                'points' => 'Points',
                'hint' => 'Hint',
                'check' => 'Check answer',
                'next' => 'Next challenge',
                'finish' => 'Complete level',
                'correct' => 'Correct! The clue has been revealed.',
                'wrong' => 'That is not the solution. Try again!',
                'hint1' => 'Look at how the number changes each time.',
                'hint2' => 'Count the objects in each group.',
                'hint3' => 'You do not need to move anything. Think about what is in front of you.',
                'p1title' => 'The Number Code',
                'p1text' => 'The stone tablet shows this sequence: 2, 4, 8, 16, __. Which number completes the code?',
                'p2title' => 'The Odd Mark',
                'p2text' => 'Three symbols follow the same rule and one does not. Which one is different?',
                'p3title' => 'The Final Question',
                'p3text' => 'The more you take away from me, the bigger I become. What am I?',
                'answer' => 'Answer',
                'placeholder' => 'Type your answer…',
                'options' => array('Circle', 'Triangle', 'Square', 'Star'),
                'puzzle2note' => 'Choose one symbol.',
                'successTitle' => 'The gate is open!',
                'successText' => 'You completed the first GrifoMania trial. Every gate hides a greater secret.',
                'restart' => 'Replay this level',
                'progress' => 'Your progress is saved on this device.',
                'saved' => 'Your progress has been saved.',
                'language' => 'Language',
                'reset' => 'Reset progress',
                'resetConfirm' => 'Are you sure you want to reset your progress?',
                'step' => 'Step',
                'complete' => 'Completed',
                'notStarted' => 'Not started',
                'guestNotice' => 'You are playing as a guest. Your progress is saved locally on this device. Google/Apple sign-in and account sync will be added in a later stage.',
                'p2shape' => 'Shape',
                'back' => 'Back to start'
            )
        )
    );

    wp_add_inline_script(
        'grifomania-game',
        'window.GrifoManiaConfig = ' . wp_json_encode($config) . ';',
        'before'
    );

    ob_start();
    ?>
    <div id="grifomania-app" class="gm-app" data-gm-version="<?php echo esc_attr(GRIFOMANIA_VERSION); ?>">
        <div class="gm-shell">
            <header class="gm-topbar">
                <div class="gm-brand"><span class="gm-brand-mark">♜</span><span>Grifo<span>Mania</span></span></div>
                <label class="gm-language"><span class="screen-reader-text">Language</span>
                    <select id="gm-language" aria-label="Language">
                        <option value="el">Ελληνικά</option>
                        <option value="en">English</option>
                    </select>
                </label>
            </header>

            <main class="gm-main">
                <section class="gm-hero" id="gm-home">
                    <div class="gm-orb gm-orb-one"></div><div class="gm-orb gm-orb-two"></div>
                    <div class="gm-hero-content">
                        <div class="gm-eyebrow" data-gm="eyebrow">ΤΟ ΜΥΣΤΙΚΟ ΤΩΝ 7 ΠΥΛΩΝ</div>
                        <div class="gm-emblem" aria-hidden="true"><span>✦</span><b>?</b><span>✦</span></div>
                        <h1 data-gm="title">Η Πρώτη Πύλη</h1>
                        <p data-gm="intro"></p>
                        <div class="gm-progress-wrap">
                            <div class="gm-progress-label"><span id="gm-progress-label">0 / 3</span><span id="gm-progress-points">0 pts</span></div>
                            <div class="gm-progress-track"><div id="gm-progress-bar"></div></div>
                        </div>
                        <button class="gm-button gm-button-primary" id="gm-start" data-gm="start">Ξεκίνα την αποστολή</button>
                        <p class="gm-guest-note" data-gm="guestNotice"></p>
                    </div>
                </section>

                <section class="gm-game hidden" id="gm-game" aria-live="polite">
                    <div class="gm-game-head">
                        <div><span class="gm-level-tag" data-gm="level"></span><h2 id="gm-puzzle-title"></h2></div>
                        <div class="gm-score"><strong id="gm-score">0</strong><small data-gm="points"></small></div>
                    </div>
                    <div class="gm-challenge-meta"><span data-gm="challenge"></span> <b id="gm-step">1</b> <span data-gm="of"></span> 3</div>
                    <div class="gm-puzzle-card">
                        <div class="gm-puzzle-art" id="gm-puzzle-art" aria-hidden="true"></div>
                        <p id="gm-puzzle-text"></p>
                        <div id="gm-answer-area"></div>
                        <div class="gm-feedback" id="gm-feedback" role="status"></div>
                        <div class="gm-actions">
                            <button class="gm-button gm-button-ghost" id="gm-hint"></button>
                            <button class="gm-button gm-button-primary" id="gm-check"></button>
                        </div>
                        <button class="gm-button gm-button-primary hidden" id="gm-next"></button>
                    </div>
                    <button class="gm-text-button" id="gm-home-button"></button>
                </section>

                <section class="gm-complete hidden" id="gm-complete">
                    <div class="gm-complete-seal">✦</div>
                    <div class="gm-eyebrow" data-gm="level"></div>
                    <h2 data-gm="successTitle"></h2>
                    <p data-gm="successText"></p>
                    <div class="gm-final-score"><strong id="gm-final-points">0</strong><span data-gm="points"></span></div>
                    <button class="gm-button gm-button-primary" id="gm-restart" data-gm="restart"></button>
                    <button class="gm-text-button" id="gm-complete-home" data-gm="back"></button>
                </section>
            </main>
            <footer class="gm-footer"><span>GRIFOMANIA · LEVEL 1</span><button id="gm-reset" type="button"></button></footer>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('grifomania', 'grifomania_shortcode');
